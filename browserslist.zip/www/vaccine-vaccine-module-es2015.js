(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vaccine-vaccine-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/vaccine.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/vaccine.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title> Vaccines</ion-title>\r\n    <ion-item slot=\"end\" color=\"primary\">\r\n      <ion-icon routerLink=\"/members/vaccine/add\" name=\"add\" slot=\"end\" color=\"light\"></ion-icon>\r\n    </ion-item>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n<!-- <ion-searchbar (ionInput)=\"onInput($event)\">\r\n\r\n</ion-searchbar> -->\r\n<ion-content>\r\n\r\n  <ion-card *ngFor=\"let vaccine of vaccines\">\r\n    <ion-item>\r\n      <ion-icon name=\"bandage-outline\" slot=\"start\" style=\"margin-right:16px\"></ion-icon>\r\n      <ion-label><b>{{vaccine.Name}}</b></ion-label>\r\n        <ion-icon  slot=\"end\" routerLink=\"/members/vaccine/edit/{{vaccine.Id}}\" color=\"primary\" name=\"create\" size=\"large\"></ion-icon>\r\n        <ion-icon  slot=\"end\" (click)=\"promptForDeleteVaccine(vaccine.Id)\" color=\"primary\" name=\"trash\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n\r\n    <ion-card-content>\r\n      <p>Minimum Age Limit: <b>{{vaccine.MinAge | number2Week}}</b></p>\r\n      <p *ngIf=\"vaccine.MaxAge\">Maximum Age Limit: <b>{{vaccine.MaxAge | number2Week}}</b></p>\r\n      <ion-button size=\"small\" fill=\"outline\" color=\"tertiary\" routerLink=\"/members/vaccine/{{vaccine.Id}}/doses\">\r\n        Doses &nbsp;\r\n        <ion-badge color=\"primary\">{{vaccine.NumOfDoses}}</ion-badge>\r\n      </ion-button>\r\n      <ion-button size=\"small\" fill=\"outline\" color=\"tertiary\" routerLink=\"/members/vaccine/{{vaccine.Id}}/brands\">\r\n        Brands &nbsp;\r\n        <ion-badge color=\"primary\">{{vaccine.NumOfBrands}}</ion-badge>\r\n      </ion-button>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n</ion-content>");

/***/ }),

/***/ "./src/app/members/vaccine/vaccine.module.ts":
/*!***************************************************!*\
  !*** ./src/app/members/vaccine/vaccine.module.ts ***!
  \***************************************************/
/*! exports provided: VaccinePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VaccinePageModule", function() { return VaccinePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _vaccine_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./vaccine.page */ "./src/app/members/vaccine/vaccine.page.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");








const routes = [
    {
        path: '',
        component: _vaccine_page__WEBPACK_IMPORTED_MODULE_6__["VaccinePage"]
    },
    { path: 'add', loadChildren: 'src/app/members/vaccine/add/add.module#AddPageModule' },
    { path: 'edit/:id', loadChildren: 'src/app/members/vaccine/edit/edit.module#EditPageModule' },
    { path: ':id/doses', loadChildren: './dose/dose.module#DosePageModule' },
    { path: ':id/brands', loadChildren: './brand/brand.module#BrandPageModule' }
];
let VaccinePageModule = class VaccinePageModule {
};
VaccinePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]
        ],
        declarations: [_vaccine_page__WEBPACK_IMPORTED_MODULE_6__["VaccinePage"]]
    })
], VaccinePageModule);



/***/ }),

/***/ "./src/app/members/vaccine/vaccine.page.scss":
/*!***************************************************!*\
  !*** ./src/app/members/vaccine/vaccine.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvdmFjY2luZS92YWNjaW5lLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/members/vaccine/vaccine.page.ts":
/*!*************************************************!*\
  !*** ./src/app/members/vaccine/vaccine.page.ts ***!
  \*************************************************/
/*! exports provided: VaccinePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VaccinePage", function() { return VaccinePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/vaccine.service */ "./src/app/services/vaccine.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/alert.service */ "./src/app/shared/alert.service.ts");
/* harmony import */ var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/toast.service */ "./src/app/shared/toast.service.ts");







let VaccinePage = class VaccinePage {
    constructor(api, route, router, loadingController, alertService, toastService) {
        this.api = api;
        this.route = route;
        this.router = router;
        this.loadingController = loadingController;
        this.alertService = alertService;
        this.toastService = toastService;
        // route.params.subscribe(val => {
        //   this.getVaccines();
        // });
    }
    ionViewWillEnter() {
        this.getVaccines();
    }
    ngOnInit() {
        // this.getVaccines();
        // this.checkNetworkStatus();
        // this.storage.get('vaccinedata').then((val) => {
        //   this.vaccines = val;
        // });
    }
    getVaccines() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Loading'
            });
            yield loading.present();
            yield this.api.getVaccines().subscribe(res => {
                this.vaccines = res.ResponseData;
                loading.dismiss();
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        });
    }
    // Alert Msg Show for deletion of vaccine
    promptForDeleteVaccine(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.alertService.confirmAlert('Are you sure you want to delete this ?', null)
                .then((yes) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                if (yes) {
                    yield this.deleteVaccine(id);
                    this.getVaccines();
                }
            }));
        });
    }
    // Call api to delete a vaccine 
    deleteVaccine(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: "Deleting"
            });
            yield loading.present();
            yield this.api.deleteVaccine(id).subscribe(res => {
                if (!res.IsSuccess) {
                    this.alertService.simpleAlert(res.Message);
                    loading.dismiss();
                }
                else {
                    this.router.navigate(['/members/vaccine']);
                    loading.dismiss();
                }
            }, err => {
                console.log(err);
                console.log("error");
                loading.dismiss();
            });
        });
    }
    onInput(ev) {
        // set val to the value of the ev target
        var val = ev.target.value;
        // if the value is an empty string don't filter the items
        if (val && val.trim() != '') {
            this.vaccines = this.vaccines.filter((item) => {
                return (item.Name.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
        }
        if (val.trim() == "") {
            this.vaccines = this.backupdoctorData;
        }
    }
};
VaccinePage.ctorParameters = () => [
    { type: src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_2__["VaccineService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"] },
    { type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"] }
];
VaccinePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-vaccine',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./vaccine.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/vaccine.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./vaccine.page.scss */ "./src/app/members/vaccine/vaccine.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_2__["VaccineService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"],
        src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"],
        src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"]])
], VaccinePage);



/***/ }),

/***/ "./src/app/shared/toast.service.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/toast.service.ts ***!
  \*****************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");



let ToastService = class ToastService {
    constructor(toastCtrl) {
        this.toastCtrl = toastCtrl;
    }
    create(message, color = "success", ok = false, duration = 3000) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.toast) {
                this.toast.dismiss();
            }
            this.toast = yield this.toastCtrl.create({
                message,
                color: color,
                duration: ok ? null : duration,
                position: 'bottom',
            });
            this.toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ })

}]);
//# sourceMappingURL=vaccine-vaccine-module-es2015.js.map