function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["dose-dose-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/dose.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/dose.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersVaccineDoseDosePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/members/dashboard\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Vaccine Dosses</ion-title>\r\n    <ion-item slot=\"end\" color=\"primary\">\r\n      <ion-icon routerLink=\"/members/vaccine/{{vaccineId}}/doses/add\" name=\"add\" slot=\"end\" color=\"light\"></ion-icon>\r\n    </ion-item>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n  <ion-card *ngFor=\"let d of dosses\">\r\n    <ion-item>\r\n      <ion-label>{{d.Name}}</ion-label>\r\n\r\n      <ion-item slot=\"end\">\r\n        <ion-icon color=\"primary\" name=\"create\" routerLink=\"/members/vaccine/{{vaccineId}}/doses/edit/{{d.Id}}\"></ion-icon>\r\n        <ion-icon (click)=\"alertDeleteDose(d.Id)\" color=\"primary\" name=\"trash\"></ion-icon>\r\n      </ion-item>\r\n    </ion-item>\r\n\r\n    <ion-card-content>\r\n      <!-- <ion-card-subtitle>Details:</ion-card-subtitle> -->\r\n      <p>Minimum Age Limit: {{d.MinAge | number2Week}}</p>\r\n      <p *ngIf=\"d.MaxAge\">Maximum Age Limit: {{d.MaxAge | number2Week}}</p>\r\n      <p *ngIf=\"d.MaxGap\">Max Gap: {{d.MaxGap | number2Week}}</p>\r\n      <p>Dose Order: {{d.DoseOrder}}</p>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/members/vaccine/dose/dose.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/members/vaccine/dose/dose.module.ts ***!
    \*****************************************************/

  /*! exports provided: DosePageModule */

  /***/
  function srcAppMembersVaccineDoseDoseModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DosePageModule", function () {
      return DosePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _dose_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./dose.page */
    "./src/app/members/vaccine/dose/dose.page.ts");
    /* harmony import */


    var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/shared.module */
    "./src/app/shared/shared.module.ts");

    var routes = [{
      path: '',
      component: _dose_page__WEBPACK_IMPORTED_MODULE_6__["DosePage"]
    }, {
      path: 'add',
      loadChildren: 'src/app/members/vaccine/dose/add/add.module#AddPageModule'
    }, {
      path: 'edit/:id1',
      loadChildren: 'src/app/members/vaccine/dose/edit/edit.module#EditPageModule'
    }];

    var DosePageModule = function DosePageModule() {
      _classCallCheck(this, DosePageModule);
    };

    DosePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]],
      declarations: [_dose_page__WEBPACK_IMPORTED_MODULE_6__["DosePage"]]
    })], DosePageModule);
    /***/
  },

  /***/
  "./src/app/members/vaccine/dose/dose.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/members/vaccine/dose/dose.page.ts ***!
    \***************************************************/

  /*! exports provided: DosePage */

  /***/
  function srcAppMembersVaccineDoseDosePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DosePage", function () {
      return DosePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/dose.service */
    "./src/app/services/dose.service.ts");
    /* harmony import */


    var src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/services/vaccine.service */
    "./src/app/services/vaccine.service.ts");
    /* harmony import */


    var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/shared/toast.service */
    "./src/app/shared/toast.service.ts");
    /* harmony import */


    var src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/alert.service */
    "./src/app/shared/alert.service.ts");

    var DosePage = /*#__PURE__*/function () {
      function DosePage(route, api, vaccineAPI, loadingController, router, toast, alertService) {
        _classCallCheck(this, DosePage);

        this.route = route;
        this.api = api;
        this.vaccineAPI = vaccineAPI;
        this.loadingController = loadingController;
        this.router = router;
        this.toast = toast;
        this.alertService = alertService;
      }

      _createClass(DosePage, [{
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.vaccineId = this.route.snapshot.paramMap.get('id');
          this.getDosses();
        } // Get all dosses base on vaccineID from server

      }, {
        key: "getDosses",
        value: function getDosses() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    _context.next = 7;
                    return this.vaccineAPI.getDosesByVaccineId(this.route.snapshot.paramMap.get('id')).subscribe(function (res) {
                      console.log(res);
                      _this.dosses = res.ResponseData;
                      loading.dismiss();
                    }, function (err) {
                      console.log(err);
                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        } // Alert Msg Show for deletion of Dose

      }, {
        key: "alertDeleteDose",
        value: function alertDeleteDose(id) {
          var _this2 = this;

          this.alertService.confirmAlert('Are you sure you want to delete this ?', null).then(function (yes) {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      if (!yes) {
                        _context2.next = 4;
                        break;
                      }

                      _context2.next = 3;
                      return this.deleteDose(id);

                    case 3:
                      this.getDosses();

                    case 4:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          });
        } // Call api to delete a vaccine 

      }, {
        key: "deleteDose",
        value: function deleteDose(id) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this3 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadingController.create({
                      message: "Deleting"
                    });

                  case 2:
                    loading = _context3.sent;
                    _context3.next = 5;
                    return loading.present();

                  case 5:
                    _context3.next = 7;
                    return this.api.deleteDose(id).subscribe(function (res) {
                      console.log(res);

                      if (!res.IsSuccess) {
                        loading.dismiss();
                      } else {
                        _this3.router.navigateByUrl('/vaccine/' + _this3.route.snapshot.paramMap.get('id') + '/dose');

                        loading.dismiss();
                      }
                    }, function (err) {
                      _this3.toast.create(err);

                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return DosePage;
    }();

    DosePage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_4__["DoseService"]
      }, {
        type: src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_5__["VaccineService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"]
      }, {
        type: src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"]
      }];
    };

    DosePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-dose',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./dose.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/dose.page.html"))["default"]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_4__["DoseService"], src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_5__["VaccineService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"], src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"]])], DosePage);
    /***/
  },

  /***/
  "./src/app/shared/toast.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/shared/toast.service.ts ***!
    \*****************************************/

  /*! exports provided: ToastService */

  /***/
  function srcAppSharedToastServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return ToastService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ToastService = /*#__PURE__*/function () {
      function ToastService(toastCtrl) {
        _classCallCheck(this, ToastService);

        this.toastCtrl = toastCtrl;
      }

      _createClass(ToastService, [{
        key: "create",
        value: function create(message) {
          var color = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "success";
          var ok = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
          var duration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 3000;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    if (this.toast) {
                      this.toast.dismiss();
                    }

                    _context4.next = 3;
                    return this.toastCtrl.create({
                      message: message,
                      color: color,
                      duration: ok ? null : duration,
                      position: 'bottom'
                    });

                  case 3:
                    this.toast = _context4.sent;
                    this.toast.present();

                  case 5:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return ToastService;
    }();

    ToastService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])], ToastService);
    /***/
  }
}]);
//# sourceMappingURL=dose-dose-module-es5.js.map