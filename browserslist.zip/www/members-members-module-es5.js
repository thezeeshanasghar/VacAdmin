function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["members-members-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/members.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/members.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersMembersPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-split-pane contentId=\"main\">\r\n  <ion-menu contentId=\"main\" type=\"overlay\">\r\n    <ion-header>\r\n      <ion-toolbar color=\"primary\">\r\n        <ion-title>Menu</ion-title>\r\n      </ion-toolbar>\r\n    </ion-header>\r\n    <ion-content color=\"light\">\r\n      <ion-list>\r\n        <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\r\n          <ion-item color=\"light\" [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\r\n            <ion-icon color=\"primary\" slot=\"start\" [name]=\"p.icon\"></ion-icon>\r\n            <ion-label>\r\n              {{p.title}}\r\n            </ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n      </ion-list>\r\n    </ion-content>\r\n    <ion-footer>\r\n\r\n      <ion-menu-toggle autoHide=\"false\" (click)=\"clearStorage()\">\r\n        <ion-item color=\"light\" routerLink=\"/login\">\r\n          <ion-icon color=\"primary\" slot=\"start\" name=\"power\"></ion-icon>\r\n          <ion-label>Logout</ion-label>\r\n        </ion-item>\r\n      </ion-menu-toggle>\r\n\r\n    </ion-footer>\r\n  </ion-menu>\r\n\r\n  <ion-router-outlet id=\"main\"></ion-router-outlet>\r\n  \r\n</ion-split-pane>";
    /***/
  },

  /***/
  "./src/app/members/members-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/members/members-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: MembersRoutingModule */

  /***/
  function srcAppMembersMembersRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MembersRoutingModule", function () {
      return MembersRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _members_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./members.page */
    "./src/app/members/members.page.ts");

    var routes = [{
      path: '',
      component: _members_page__WEBPACK_IMPORTED_MODULE_3__["MembersPage"],
      children: [{
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      }, // { path: '', loadChildren: './dashboard/dashboard.module#DashboardPageModule' },
      {
        path: 'dashboard',
        loadChildren: './dashboard/dashboard.module#DashboardPageModule'
      }, {
        path: 'vaccine',
        loadChildren: './vaccine/vaccine.module#VaccinePageModule'
      }, {
        path: 'doctor',
        loadChildren: './doctor/doctor.module#DoctorPageModule'
      }, {
        path: 'child',
        loadChildren: './child/child.module#ChildPageModule'
      }, {
        path: 'message',
        loadChildren: './message/message.module#MessagePageModule'
      }]
    }];

    var MembersRoutingModule = function MembersRoutingModule() {
      _classCallCheck(this, MembersRoutingModule);
    };

    MembersRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MembersRoutingModule);
    /***/
  },

  /***/
  "./src/app/members/members.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/members/members.module.ts ***!
    \*******************************************/

  /*! exports provided: MembersPageModule */

  /***/
  function srcAppMembersMembersModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MembersPageModule", function () {
      return MembersPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _members_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./members.page */
    "./src/app/members/members.page.ts");
    /* harmony import */


    var _members_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./members-routing.module */
    "./src/app/members/members-routing.module.ts");

    var MembersPageModule = function MembersPageModule() {
      _classCallCheck(this, MembersPageModule);
    };

    MembersPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_members_page__WEBPACK_IMPORTED_MODULE_5__["MembersPage"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _members_routing_module__WEBPACK_IMPORTED_MODULE_6__["MembersRoutingModule"]]
    })], MembersPageModule);
    /***/
  },

  /***/
  "./src/app/members/members.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/members/members.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppMembersMembersPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvbWVtYmVycy5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/members/members.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/members/members.page.ts ***!
    \*****************************************/

  /*! exports provided: MembersPage */

  /***/
  function srcAppMembersMembersPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MembersPage", function () {
      return MembersPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");

    var MembersPage = /*#__PURE__*/function () {
      function MembersPage(storage) {
        _classCallCheck(this, MembersPage);

        this.storage = storage;
        this.appPages = [{
          title: 'Dashboard',
          url: '/members/dashboard',
          icon: 'home'
        }, {
          title: 'Vaccines',
          url: '/members/vaccine',
          icon: 'color-filter'
        }, {
          title: 'Doctors',
          url: '/members/doctor',
          icon: 'medkit'
        }, {
          title: 'Patients',
          url: '/members/child',
          icon: 'man'
        }, {
          title: 'Messages',
          url: '/members/message',
          icon: 'mail'
        }];
      }

      _createClass(MembersPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "clearStorage",
        value: function clearStorage() {
          this.storage.clear();
        }
      }]);

      return MembersPage;
    }();

    MembersPage.ctorParameters = function () {
      return [{
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]
      }];
    };

    MembersPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-members',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./members.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/members.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./members.page.scss */
      "./src/app/members/members.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]])], MembersPage);
    /***/
  }
}]);
//# sourceMappingURL=members-members-module-es5.js.map