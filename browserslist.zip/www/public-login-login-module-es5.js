function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["public-login-login-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/public/login/login.page.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/public/login/login.page.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPublicLoginLoginPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title>Login</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-card style=\"background-color: #d3cccc94;\">\r\n    <ion-card-content>\r\n\r\n      <form [formGroup]=\"fg\">\r\n\r\n        <ion-label color=\"primary\" position=\"floating\">\r\n          <ion-icon name=\"mail\" item-start></ion-icon>\r\n          Mobile Number\r\n        </ion-label>\r\n        <ion-input type=\"email\" formControlName=\"MobileNumber\"></ion-input>\r\n\r\n\r\n        <ion-label color=\"primary\" position=\"floating\">\r\n          <ion-icon name=\"lock\" item-start></ion-icon>\r\n          Password\r\n        </ion-label>\r\n        <ion-input type=\"password\" formControlName=\"Password\"></ion-input>\r\n\r\n\r\n        <ion-button expand=\"full\" color=\"tertiary\" (click)=\"login()\">\r\n          <ion-icon name=\"log-in\"></ion-icon>&nbsp;\r\n          Login\r\n        </ion-button>\r\n      </form>\r\n      <ion-text text-right>\r\n        <a (click)=\"forgotPasswordAlert()\">\r\n          <h2>Forget password</h2>\r\n        </a>\r\n      </ion-text>\r\n\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/public/login/login.module.ts":
  /*!**********************************************!*\
    !*** ./src/app/public/login/login.module.ts ***!
    \**********************************************/

  /*! exports provided: LoginPageModule */

  /***/
  function srcAppPublicLoginLoginModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPageModule", function () {
      return LoginPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./login.page */
    "./src/app/public/login/login.page.ts");

    var routes = [{
      path: '',
      component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }];

    var LoginPageModule = function LoginPageModule() {
      _classCallCheck(this, LoginPageModule);
    };

    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })], LoginPageModule);
    /***/
  },

  /***/
  "./src/app/public/login/login.page.scss":
  /*!**********************************************!*\
    !*** ./src/app/public/login/login.page.scss ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppPublicLoginLoginPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #fff url('login.jpg') no-repeat center center / cover;\n}\n\nion-card {\n  margin-top: 15%;\n  align-content: center;\n  width: 80%;\n  margin-left: 10%;\n}\n\nion-input {\n  border-bottom: 1px solid #292727;\n  --padding-start: 7px;\n}\n\n.item.item-trns {\n  border-color: rgba(0, 0, 0, 0);\n  background-color: rgba(0, 0, 0, 0);\n  color: white;\n}\n\nh2 {\n  color: #0039a2;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHVibGljL2xvZ2luL0U6XFxOZXcgZm9sZGVyXFxWYWNBZG1pbi9zcmNcXGFwcFxccHVibGljXFxsb2dpblxcbG9naW4ucGFnZS5zY3NzIiwic3JjL2FwcC9wdWJsaWMvbG9naW4vbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUVBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtBQ0NKOztBREVBO0VBQ0ksZ0NBQUE7RUFDQSxvQkFBQTtBQ0NKOztBREdBO0VBQ0MsOEJBQUE7RUFDQSxrQ0FBQTtFQUNBLFlBQUE7QUNBRDs7QURHQTtFQUNJLGNBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3B1YmxpYy9sb2dpbi9sb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC0tYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uLy4uL2Fzc2V0cy9sb2dpbi5qcGcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG59XHJcblxyXG5pb24tY2FyZHtcclxuICAgIG1hcmdpbi10b3A6IDE1JTtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogMTAlO1xyXG59XHJcblxyXG5pb24taW5wdXR7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiKDQxLCAzOSwgMzkpO1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA3cHg7XHJcbn1cclxuXHJcblxyXG4uaXRlbS5pdGVtLXRybnMge1xyXG5cdGJvcmRlci1jb2xvcjogcmdiYSgwLCAwLCAwLCAwKTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDApO1xyXG5cdGNvbG9yOiB3aGl0ZTsgXHJcbn1cclxuXHJcbmgye1xyXG4gICAgY29sb3I6IzAwMzlhMjtcclxufVxyXG5cclxuIiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmZmYgdXJsKFwiLi4vLi4vLi4vYXNzZXRzL2xvZ2luLmpwZ1wiKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xufVxuXG5pb24tY2FyZCB7XG4gIG1hcmdpbi10b3A6IDE1JTtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuICB3aWR0aDogODAlO1xuICBtYXJnaW4tbGVmdDogMTAlO1xufVxuXG5pb24taW5wdXQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzI5MjcyNztcbiAgLS1wYWRkaW5nLXN0YXJ0OiA3cHg7XG59XG5cbi5pdGVtLml0ZW0tdHJucyB7XG4gIGJvcmRlci1jb2xvcjogcmdiYSgwLCAwLCAwLCAwKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwKTtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG5oMiB7XG4gIGNvbG9yOiAjMDAzOWEyO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/public/login/login.page.ts":
  /*!********************************************!*\
    !*** ./src/app/public/login/login.page.ts ***!
    \********************************************/

  /*! exports provided: LoginPage */

  /***/
  function srcAppPublicLoginLoginPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPage", function () {
      return LoginPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/login.service */
    "./src/app/services/login.service.ts");
    /* harmony import */


    var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/toast.service */
    "./src/app/shared/toast.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var LoginPage = /*#__PURE__*/function () {
      function LoginPage(router, alertController, formBuilder, loginService, toastService, storage) {
        _classCallCheck(this, LoginPage);

        this.router = router;
        this.alertController = alertController;
        this.formBuilder = formBuilder;
        this.loginService = loginService;
        this.toastService = toastService;
        this.storage = storage;
      }

      _createClass(LoginPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.skipLoginIfAlreadyLoggedIn();
          this.fg = this.formBuilder.group({
            'MobileNumber': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'Password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'CountryCode': ['92'],
            'UserType': ['SUPERADMIN']
          });
        }
      }, {
        key: "skipLoginIfAlreadyLoggedIn",
        value: function skipLoginIfAlreadyLoggedIn() {
          var _this = this;

          this.storage.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].IS_LOGGED_IN).then(function (value) {
            if (value) {
              _this.loginService.changeState(value);

              _this.router.navigate(['members/dashboard']);
            }
          });
        }
      }, {
        key: "login",
        value: function login() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loginService.checkAuth(this.fg.value).subscribe(function (res) {
                      if (res.IsSuccess) {
                        _this2.loginService.changeState(true);

                        _this2.storage.set(src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].IS_LOGGED_IN, true);

                        _this2.router.navigate(['/members/']);
                      } else {
                        _this2.toastService.create(res.Message, 'danger');
                      }
                    }, function (err) {
                      console.log(err);

                      _this2.toastService.create(err);
                    });

                  case 2:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        } // show Alert msg for forgot password

      }, {
        key: "forgotPasswordAlert",
        value: function forgotPasswordAlert() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.alertController.create({
                      header: 'Forgot Password',
                      inputs: [{
                        name: 'MobileNumber',
                        type: 'text',
                        placeholder: 'like 3211231231'
                      }],
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {}
                      }, {
                        text: 'Send Email/SMS',
                        handler: function handler(data) {
                          _this3.forgotPassword(data.MobileNumber);
                        }
                      }]
                    });

                  case 2:
                    alert = _context2.sent;
                    _context2.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        } // Call api to forgot password

      }, {
        key: "forgotPassword",
        value: function forgotPassword(MobileNumber) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this4 = this;

            var data;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    data = {
                      'CountryCode': '92',
                      'UserType': 'SUPERADMIN',
                      'MobileNumber': MobileNumber
                    };
                    _context3.next = 3;
                    return this.loginService.forgotPassword(data).subscribe(function (res) {
                      if (res.IsSuccess) {} else {
                        _this4.toastService.create(res.Message, 'danger');
                      }
                    }, function (err) {
                      console.log(err);

                      _this4.toastService.create(err, 'danger');
                    });

                  case 3:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return LoginPage;
    }();

    LoginPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_4__["LoginService"]
      }, {
        type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]
      }];
    };

    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-login',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./login.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/public/login/login.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./login.page.scss */
      "./src/app/public/login/login.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], src_app_services_login_service__WEBPACK_IMPORTED_MODULE_4__["LoginService"], src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]])], LoginPage);
    /***/
  },

  /***/
  "./src/app/shared/toast.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/shared/toast.service.ts ***!
    \*****************************************/

  /*! exports provided: ToastService */

  /***/
  function srcAppSharedToastServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return ToastService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ToastService = /*#__PURE__*/function () {
      function ToastService(toastCtrl) {
        _classCallCheck(this, ToastService);

        this.toastCtrl = toastCtrl;
      }

      _createClass(ToastService, [{
        key: "create",
        value: function create(message) {
          var color = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "success";
          var ok = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
          var duration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 3000;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    if (this.toast) {
                      this.toast.dismiss();
                    }

                    _context4.next = 3;
                    return this.toastCtrl.create({
                      message: message,
                      color: color,
                      duration: ok ? null : duration,
                      position: 'bottom'
                    });

                  case 3:
                    this.toast = _context4.sent;
                    this.toast.present();

                  case 5:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return ToastService;
    }();

    ToastService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])], ToastService);
    /***/
  }
}]);
//# sourceMappingURL=public-login-login-module-es5.js.map