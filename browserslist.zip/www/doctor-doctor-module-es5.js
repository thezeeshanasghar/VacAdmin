function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["doctor-doctor-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/doctor.page.html":
  /*!***************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/doctor.page.html ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersDoctorDoctorPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n    <ion-toolbar color=\"primary\">\r\n      <ion-buttons slot=\"start\">\r\n        <ion-menu-button></ion-menu-button>\r\n      </ion-buttons>\r\n      <ion-title>Doctors</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n\r\n<ion-content padding>\r\n\r\n    <ion-tabs>\r\n        <ion-tab-bar slot=\"bottom\">\r\n          <ion-tab-button tab=\"approved\">\r\n            <ion-icon name=\"checkbox-outline\"></ion-icon>\r\n            <ion-label>Approved</ion-label>\r\n            <ion-badge *ngIf=\"approvedCount\">{{approvedCount}}</ion-badge>\r\n          </ion-tab-button>\r\n    \r\n          <ion-tab-button tab=\"unapproved\">\r\n           <ion-icon name=\"close-circle-outline\"></ion-icon>\r\n           <ion-label>Not Approved</ion-label>\r\n           <ion-badge *ngIf=\"unapprovedCount\">{{unapprovedCount}}</ion-badge>\r\n          </ion-tab-button>\r\n        </ion-tab-bar>\r\n      </ion-tabs>\r\n    \r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/members/doctor/doctor.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/members/doctor/doctor.module.ts ***!
    \*************************************************/

  /*! exports provided: DoctorPageModule */

  /***/
  function srcAppMembersDoctorDoctorModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DoctorPageModule", function () {
      return DoctorPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _doctor_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./doctor.page */
    "./src/app/members/doctor/doctor.page.ts");

    var routes = [{
      path: '',
      component: _doctor_page__WEBPACK_IMPORTED_MODULE_6__["DoctorPage"],
      children: [{
        path: '',
        redirectTo: 'approved',
        pathMatch: 'full'
      }, {
        path: 'approved',
        loadChildren: './approved/approved.module#ApprovedPageModule'
      }, {
        path: 'unapproved',
        loadChildren: './unapproved/unapproved.module#UnapprovedPageModule'
      }]
    }, {
      path: ':id/permissions',
      loadChildren: './permission/permission.module#PermissionPageModule'
    }];

    var DoctorPageModule = function DoctorPageModule() {
      _classCallCheck(this, DoctorPageModule);
    };

    DoctorPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_doctor_page__WEBPACK_IMPORTED_MODULE_6__["DoctorPage"]]
    })], DoctorPageModule);
    /***/
  },

  /***/
  "./src/app/members/doctor/doctor.page.scss":
  /*!*************************************************!*\
    !*** ./src/app/members/doctor/doctor.page.scss ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMembersDoctorDoctorPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvZG9jdG9yL2RvY3Rvci5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/members/doctor/doctor.page.ts":
  /*!***********************************************!*\
    !*** ./src/app/members/doctor/doctor.page.ts ***!
    \***********************************************/

  /*! exports provided: DoctorPage */

  /***/
  function srcAppMembersDoctorDoctorPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DoctorPage", function () {
      return DoctorPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js"); //import { Events } from '@ionic/angular';


    var DoctorPage = /*#__PURE__*/function () {
      function DoctorPage() {
        _classCallCheck(this, DoctorPage);
      } //constructor(private event: Events) { }


      _createClass(DoctorPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {// this.event.subscribe('approvedCount', (count) => {
          //   this.approvedCount = count;
          // });
          // this.event.subscribe('unapprovedCount', (count) => {
          //   this.unapprovedCount = count;
          // });
        }
      }]);

      return DoctorPage;
    }();

    DoctorPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-doctor',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./doctor.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/doctor.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./doctor.page.scss */
      "./src/app/members/doctor/doctor.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], DoctorPage);
    /***/
  }
}]);
//# sourceMappingURL=doctor-doctor-module-es5.js.map