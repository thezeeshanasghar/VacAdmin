function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { return function () { var Super = _getPrototypeOf(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["brand-brand-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/brand/brand.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/brand/brand.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersVaccineBrandBrandPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/members/dashboard\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Vaccine Brands</ion-title>\r\n    <ion-item slot=\"end\" color=\"primary\">\r\n      <ion-icon (click)=\"alertMsgForAdd()\" name=\"add\" slot=\"end\" color=\"light\"></ion-icon>\r\n    </ion-item>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n  <ion-card *ngFor=\"let b of brands\">\r\n    <ion-item>\r\n      <ion-icon name=\"color-filter\" slot=\"start\" style=\"margin-right:16px\"></ion-icon>\r\n      <ion-label>{{b.Name}}</ion-label>\r\n      <ion-item slot=\"end\">\r\n        <ion-icon (click)=\"getBrandsbyId(b.Id)\" color=\"primary\" name=\"create\"></ion-icon>\r\n        <ion-icon (click)=\"alertDeletevaccine(b.Id)\" color=\"primary\" name=\"trash\"></ion-icon>\r\n      </ion-item>\r\n    </ion-item>\r\n  </ion-card>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/members/vaccine/brand/brand.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/members/vaccine/brand/brand.module.ts ***!
    \*******************************************************/

  /*! exports provided: BrandPageModule */

  /***/
  function srcAppMembersVaccineBrandBrandModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrandPageModule", function () {
      return BrandPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _brand_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./brand.page */
    "./src/app/members/vaccine/brand/brand.page.ts");

    var routes = [{
      path: '',
      component: _brand_page__WEBPACK_IMPORTED_MODULE_6__["BrandPage"]
    }];

    var BrandPageModule = function BrandPageModule() {
      _classCallCheck(this, BrandPageModule);
    };

    BrandPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_brand_page__WEBPACK_IMPORTED_MODULE_6__["BrandPage"]]
    })], BrandPageModule);
    /***/
  },

  /***/
  "./src/app/members/vaccine/brand/brand.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/members/vaccine/brand/brand.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMembersVaccineBrandBrandPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvdmFjY2luZS9icmFuZC9icmFuZC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/members/vaccine/brand/brand.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/members/vaccine/brand/brand.page.ts ***!
    \*****************************************************/

  /*! exports provided: BrandPage */

  /***/
  function srcAppMembersVaccineBrandBrandPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrandPage", function () {
      return BrandPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_services_brand_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/brand.service */
    "./src/app/services/brand.service.ts");
    /* harmony import */


    var src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/vaccine.service */
    "./src/app/services/vaccine.service.ts");
    /* harmony import */


    var src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/alert.service */
    "./src/app/shared/alert.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/toast.service */
    "./src/app/shared/toast.service.ts");

    var BrandPage = /*#__PURE__*/function () {
      function BrandPage(route, router, api, vaccineAPI, alertService, loadingController, toastservice, alertController) {
        _classCallCheck(this, BrandPage);

        this.route = route;
        this.router = router;
        this.api = api;
        this.vaccineAPI = vaccineAPI;
        this.alertService = alertService;
        this.loadingController = loadingController;
        this.toastservice = toastservice;
        this.alertController = alertController;
      }

      _createClass(BrandPage, [{
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.vaccineID = this.route.snapshot.paramMap.get('id');
          this.getBrands();
        } // Get all brands base on vaccine id

      }, {
        key: "getBrands",
        value: function getBrands() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    _context.next = 7;
                    return this.vaccineAPI.getBrandsByVaccineId(this.vaccineID).subscribe(function (res) {
                      _this.brands = res.ResponseData;
                      console.log(_this.brands);
                      loading.dismiss();
                    }, function (err) {
                      console.log(err);
                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        } // Get single brand data base on brand id

      }, {
        key: "getBrandsbyId",
        value: function getBrandsbyId(id) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this2 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context2.sent;
                    _context2.next = 5;
                    return loading.present();

                  case 5:
                    _context2.next = 7;
                    return this.api.getBrandById(id).subscribe(function (res) {
                      _this2.singlebrands = res.ResponseData;
                      loading.dismiss();

                      _this2.alertMsgForEdit(_this2.singlebrands.Name, id);
                    }, function (err) {
                      console.log(err);
                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        } // AlertMsg Show for Add Brand Name

      }, {
        key: "alertMsgForAdd",
        value: function alertMsgForAdd() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertController.create({
                      header: 'Add New',
                      inputs: [{
                        name: 'BrandName',
                        type: 'text',
                        placeholder: 'Brand Name'
                      }],
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Confirm Cancel');
                        }
                      }, {
                        text: 'Add',
                        handler: function handler(data) {
                          _this3.Name = data.BrandName;

                          _this3.AddBrand();

                          console.log('Confirm Ok');
                        }
                      }]
                    });

                  case 2:
                    alert = _context3.sent;
                    _context3.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        } // Request send to sever for Add a brand

      }, {
        key: "AddBrand",
        value: function AddBrand() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var _this4 = this;

            var userData1;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    userData1 = {
                      "Name": this.Name,
                      "VaccineID": this.vaccineID
                    };
                    console.log(userData1);
                    _context4.next = 4;
                    return this.api.addBrand(this.vaccineID, userData1).subscribe(function (res) {
                      _this4.getBrands();
                    }, function (err) {
                      console.log(err);
                    });

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        } // AlertMsg Show for Edit Brand Name

      }, {
        key: "alertMsgForEdit",
        value: function alertMsgForEdit(brandname, id) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var _this5 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.alertController.create({
                      header: 'Edit Name',
                      inputs: [{
                        name: 'BrandName',
                        value: brandname
                      }],
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          console.log('Confirm Cancel');
                        }
                      }, {
                        text: 'Update',
                        handler: function handler(data) {
                          _this5.Name = data.BrandName;

                          _this5.editBrand(id);

                          console.log('Confirm Ok');
                        }
                      }]
                    });

                  case 2:
                    alert = _context5.sent;
                    _context5.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        } // Request send to sever update a brand name

      }, {
        key: "editBrand",
        value: function editBrand(id) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var _this6 = this;

            var userData;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    userData = {
                      "ID": this.singlebrands.ID,
                      "Name": this.Name,
                      "VaccineID": this.singlebrands.VaccineID
                    };
                    console.log(userData);
                    _context6.next = 4;
                    return this.api.editBrand(id, userData).subscribe(function (res) {
                      _this6.getBrands();
                    }, function (err) {
                      console.log(err);
                    });

                  case 4:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        } // Alert Msg Show for deletion of Brand

      }, {
        key: "alertDeletevaccine",
        value: function alertDeletevaccine(id) {
          var _this7 = this;

          this.alertService.confirmAlert('Are you sure you want to delete this ?', null).then(function (yes) {
            if (yes) {
              _this7.Deletevacc(id);
            }
          });
        } // Call api to delete a vaccine 

      }, {
        key: "Deletevacc",
        value: function Deletevacc(id) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var _this8 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    _context7.next = 2;
                    return this.loadingController.create({
                      message: "Loading"
                    });

                  case 2:
                    loading = _context7.sent;
                    _context7.next = 5;
                    return loading.present();

                  case 5:
                    _context7.next = 7;
                    return this.api.deleteBrand(id).subscribe(function (res) {
                      if (res.IsSuccess == true) {
                        _this8.getBrands();

                        loading.dismiss();
                      } else {
                        loading.dismiss();

                        _this8.toastservice.create(res.Message);
                      }
                    }, function (err) {
                      loading.dismiss();

                      _this8.toastservice.create(err);
                    });

                  case 7:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }]);

      return BrandPage;
    }();

    BrandPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: src_app_services_brand_service__WEBPACK_IMPORTED_MODULE_3__["BrandService"]
      }, {
        type: src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_4__["VaccineService"]
      }, {
        type: src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"]
      }, {
        type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_7__["ToastService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]
      }];
    };

    BrandPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-brand',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./brand.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/brand/brand.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./brand.page.scss */
      "./src/app/members/vaccine/brand/brand.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], src_app_services_brand_service__WEBPACK_IMPORTED_MODULE_3__["BrandService"], src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_4__["VaccineService"], src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"], src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_7__["ToastService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]])], BrandPage);
    /***/
  },

  /***/
  "./src/app/services/brand.service.ts":
  /*!*******************************************!*\
    !*** ./src/app/services/brand.service.ts ***!
    \*******************************************/

  /*! exports provided: BrandService */

  /***/
  function srcAppServicesBrandServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrandService", function () {
      return BrandService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _base_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./base.service */
    "./src/app/services/base.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var BrandService = /*#__PURE__*/function (_base_service__WEBPAC) {
      _inherits(BrandService, _base_service__WEBPAC);

      var _super = _createSuper(BrandService);

      function BrandService(http) {
        var _this9;

        _classCallCheck(this, BrandService);

        _this9 = _super.call(this, http);
        _this9.http = http;
        _this9.API_BRAND = "".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].BASE_URL, "brand");
        return _this9;
      }

      _createClass(BrandService, [{
        key: "getBrandById",
        value: function getBrandById(brandId) {
          var url = "".concat(this.API_BRAND, "/").concat(brandId);
          return this.http.get(url, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(this.extractData), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
        }
      }, {
        key: "addBrand",
        value: function addBrand(vaccineId, data) {
          var url = "".concat(this.API_BRAND, "/").concat(vaccineId);
          return this.http.post(url, data, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
        }
      }, {
        key: "editBrand",
        value: function editBrand(id, data) {
          var url = "".concat(this.API_BRAND, "/").concat(id);
          return this.http.put(url, data, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
        }
      }, {
        key: "deleteBrand",
        value: function deleteBrand(id) {
          var url = "".concat(this.API_BRAND, "/").concat(id);
          return this.http["delete"](url, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
        }
      }]);

      return BrandService;
    }(_base_service__WEBPACK_IMPORTED_MODULE_2__["BaseService"]);

    BrandService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }];
    };

    BrandService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])], BrandService);
    /***/
  },

  /***/
  "./src/app/shared/toast.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/shared/toast.service.ts ***!
    \*****************************************/

  /*! exports provided: ToastService */

  /***/
  function srcAppSharedToastServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return ToastService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ToastService = /*#__PURE__*/function () {
      function ToastService(toastCtrl) {
        _classCallCheck(this, ToastService);

        this.toastCtrl = toastCtrl;
      }

      _createClass(ToastService, [{
        key: "create",
        value: function create(message) {
          var color = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "success";
          var ok = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
          var duration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 3000;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    if (this.toast) {
                      this.toast.dismiss();
                    }

                    _context8.next = 3;
                    return this.toastCtrl.create({
                      message: message,
                      color: color,
                      duration: ok ? null : duration,
                      position: 'bottom'
                    });

                  case 3:
                    this.toast = _context8.sent;
                    this.toast.present();

                  case 5:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }]);

      return ToastService;
    }();

    ToastService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])], ToastService);
    /***/
  }
}]);
//# sourceMappingURL=brand-brand-module-es5.js.map