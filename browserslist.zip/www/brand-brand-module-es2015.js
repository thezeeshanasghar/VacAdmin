(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["brand-brand-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/brand/brand.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/brand/brand.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/members/dashboard\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Vaccine Brands</ion-title>\r\n    <ion-item slot=\"end\" color=\"primary\">\r\n      <ion-icon (click)=\"alertMsgForAdd()\" name=\"add\" slot=\"end\" color=\"light\"></ion-icon>\r\n    </ion-item>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n  <ion-card *ngFor=\"let b of brands\">\r\n    <ion-item>\r\n      <ion-icon name=\"color-filter\" slot=\"start\" style=\"margin-right:16px\"></ion-icon>\r\n      <ion-label>{{b.Name}}</ion-label>\r\n      <ion-item slot=\"end\">\r\n        <ion-icon (click)=\"getBrandsbyId(b.Id)\" color=\"primary\" name=\"create\"></ion-icon>\r\n        <ion-icon (click)=\"alertDeletevaccine(b.Id)\" color=\"primary\" name=\"trash\"></ion-icon>\r\n      </ion-item>\r\n    </ion-item>\r\n  </ion-card>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/members/vaccine/brand/brand.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/members/vaccine/brand/brand.module.ts ***!
  \*******************************************************/
/*! exports provided: BrandPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrandPageModule", function() { return BrandPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _brand_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./brand.page */ "./src/app/members/vaccine/brand/brand.page.ts");







const routes = [
    {
        path: '',
        component: _brand_page__WEBPACK_IMPORTED_MODULE_6__["BrandPage"]
    }
];
let BrandPageModule = class BrandPageModule {
};
BrandPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_brand_page__WEBPACK_IMPORTED_MODULE_6__["BrandPage"]]
    })
], BrandPageModule);



/***/ }),

/***/ "./src/app/members/vaccine/brand/brand.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/members/vaccine/brand/brand.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvdmFjY2luZS9icmFuZC9icmFuZC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/members/vaccine/brand/brand.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/members/vaccine/brand/brand.page.ts ***!
  \*****************************************************/
/*! exports provided: BrandPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrandPage", function() { return BrandPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_services_brand_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/brand.service */ "./src/app/services/brand.service.ts");
/* harmony import */ var src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/vaccine.service */ "./src/app/services/vaccine.service.ts");
/* harmony import */ var src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/alert.service */ "./src/app/shared/alert.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/toast.service */ "./src/app/shared/toast.service.ts");








let BrandPage = class BrandPage {
    constructor(route, router, api, vaccineAPI, alertService, loadingController, toastservice, alertController) {
        this.route = route;
        this.router = router;
        this.api = api;
        this.vaccineAPI = vaccineAPI;
        this.alertService = alertService;
        this.loadingController = loadingController;
        this.toastservice = toastservice;
        this.alertController = alertController;
    }
    ionViewWillEnter() {
        this.vaccineID = this.route.snapshot.paramMap.get('id');
        this.getBrands();
    }
    // Get all brands base on vaccine id
    getBrands() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Loading'
            });
            yield loading.present();
            yield this.vaccineAPI.getBrandsByVaccineId(this.vaccineID).subscribe(res => {
                this.brands = res.ResponseData;
                console.log(this.brands);
                loading.dismiss();
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        });
    }
    // Get single brand data base on brand id
    getBrandsbyId(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Loading'
            });
            yield loading.present();
            yield this.api.getBrandById(id).subscribe(res => {
                this.singlebrands = res.ResponseData;
                loading.dismiss();
                this.alertMsgForEdit(this.singlebrands.Name, id);
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        });
    }
    // AlertMsg Show for Add Brand Name
    alertMsgForAdd() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Add New',
                inputs: [
                    {
                        name: 'BrandName',
                        type: 'text',
                        placeholder: 'Brand Name',
                    },
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            console.log('Confirm Cancel');
                        }
                    }, {
                        text: 'Add',
                        handler: (data) => {
                            this.Name = data.BrandName;
                            this.AddBrand();
                            console.log('Confirm Ok');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    // Request send to sever for Add a brand
    AddBrand() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let userData1 = { "Name": this.Name, "VaccineID": this.vaccineID };
            console.log(userData1);
            yield this.api.addBrand(this.vaccineID, userData1)
                .subscribe(res => {
                this.getBrands();
            }, (err) => {
                console.log(err);
            });
        });
    }
    // AlertMsg Show for Edit Brand Name
    alertMsgForEdit(brandname, id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            //this.getBrandsbyId(id)
            const alert = yield this.alertController.create({
                header: 'Edit Name',
                inputs: [
                    {
                        name: 'BrandName',
                        value: brandname,
                    },
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            console.log('Confirm Cancel');
                        }
                    }, {
                        text: 'Update',
                        handler: (data) => {
                            this.Name = data.BrandName;
                            this.editBrand(id);
                            console.log('Confirm Ok');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    // Request send to sever update a brand name
    editBrand(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let userData = { "ID": this.singlebrands.ID, "Name": this.Name, "VaccineID": this.singlebrands.VaccineID };
            console.log(userData);
            yield this.api.editBrand(id, userData)
                .subscribe(res => {
                this.getBrands();
            }, (err) => {
                console.log(err);
            });
        });
    }
    // Alert Msg Show for deletion of Brand
    alertDeletevaccine(id) {
        this.alertService.confirmAlert('Are you sure you want to delete this ?', null)
            .then((yes) => {
            if (yes) {
                this.Deletevacc(id);
            }
        });
    }
    // Call api to delete a vaccine 
    Deletevacc(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: "Loading"
            });
            yield loading.present();
            yield this.api.deleteBrand(id).subscribe(res => {
                if (res.IsSuccess == true) {
                    this.getBrands();
                    loading.dismiss();
                }
                else {
                    loading.dismiss();
                    this.toastservice.create(res.Message);
                }
            }, err => {
                loading.dismiss();
                this.toastservice.create(err);
            });
        });
    }
};
BrandPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: src_app_services_brand_service__WEBPACK_IMPORTED_MODULE_3__["BrandService"] },
    { type: src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_4__["VaccineService"] },
    { type: src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_7__["ToastService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] }
];
BrandPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-brand',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./brand.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/brand/brand.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./brand.page.scss */ "./src/app/members/vaccine/brand/brand.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        src_app_services_brand_service__WEBPACK_IMPORTED_MODULE_3__["BrandService"],
        src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_4__["VaccineService"],
        src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"],
        src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_7__["ToastService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]])
], BrandPage);



/***/ }),

/***/ "./src/app/services/brand.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/brand.service.ts ***!
  \*******************************************/
/*! exports provided: BrandService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrandService", function() { return BrandService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _base_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base.service */ "./src/app/services/base.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");






let BrandService = class BrandService extends _base_service__WEBPACK_IMPORTED_MODULE_2__["BaseService"] {
    constructor(http) {
        super(http);
        this.http = http;
        this.API_BRAND = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].BASE_URL}brand`;
    }
    getBrandById(brandId) {
        const url = `${this.API_BRAND}/${brandId}`;
        return this.http.get(url, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(this.extractData), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    addBrand(vaccineId, data) {
        const url = `${this.API_BRAND}/${vaccineId}`;
        return this.http.post(url, data, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    editBrand(id, data) {
        const url = `${this.API_BRAND}/${id}`;
        return this.http.put(url, data, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
    deleteBrand(id) {
        const url = `${this.API_BRAND}/${id}`;
        return this.http.delete(url, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError));
    }
};
BrandService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
BrandService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
], BrandService);



/***/ }),

/***/ "./src/app/shared/toast.service.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/toast.service.ts ***!
  \*****************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");



let ToastService = class ToastService {
    constructor(toastCtrl) {
        this.toastCtrl = toastCtrl;
    }
    create(message, color = "success", ok = false, duration = 3000) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.toast) {
                this.toast.dismiss();
            }
            this.toast = yield this.toastCtrl.create({
                message,
                color: color,
                duration: ok ? null : duration,
                position: 'bottom',
            });
            this.toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ })

}]);
//# sourceMappingURL=brand-brand-module-es2015.js.map