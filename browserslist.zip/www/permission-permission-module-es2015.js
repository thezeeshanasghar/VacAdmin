(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["permission-permission-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/permission/permission.page.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/permission/permission.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/members/dashboard\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Doctor Permission</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n  <ion-list no-lines>\r\n    <ion-item>\r\n      <ion-label color=\"dark\" text-center>\r\n        {{doctor.DisplayName}}\r\n      </ion-label>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label>Allow Invoice</ion-label>\r\n      <ion-checkbox [(ngModel)]=\"doctor.AllowInvoice\"></ion-checkbox>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label>Allow Follow up</ion-label>\r\n      <ion-checkbox [(ngModel)]=\"doctor.AllowFollowUp\"></ion-checkbox>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label>Allow Chart</ion-label>\r\n      <ion-checkbox [(ngModel)]=\"doctor.AllowChart\"></ion-checkbox>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label>Allow inventory</ion-label>\r\n      <ion-checkbox [(ngModel)]=\"doctor.AllowInventory\"></ion-checkbox>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label>SMS Limit</ion-label>\r\n      <ion-input slot=\"end\" type=\"number\" placeholder=\"SMS limit\" [(ngModel)]=\"doctor.SMSLimit\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-button expand=\"block\" (click)=\"update()\">Update Permission</ion-button>\r\n\r\n  </ion-list>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/members/doctor/permission/permission.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/members/doctor/permission/permission.module.ts ***!
  \****************************************************************/
/*! exports provided: PermissionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionPageModule", function() { return PermissionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _permission_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./permission.page */ "./src/app/members/doctor/permission/permission.page.ts");







const routes = [
    {
        path: '',
        component: _permission_page__WEBPACK_IMPORTED_MODULE_6__["PermissionPage"]
    }
];
let PermissionPageModule = class PermissionPageModule {
};
PermissionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_permission_page__WEBPACK_IMPORTED_MODULE_6__["PermissionPage"]]
    })
], PermissionPageModule);



/***/ }),

/***/ "./src/app/members/doctor/permission/permission.page.scss":
/*!****************************************************************!*\
  !*** ./src/app/members/doctor/permission/permission.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvZG9jdG9yL3Blcm1pc3Npb24vcGVybWlzc2lvbi5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/members/doctor/permission/permission.page.ts":
/*!**************************************************************!*\
  !*** ./src/app/members/doctor/permission/permission.page.ts ***!
  \**************************************************************/
/*! exports provided: PermissionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionPage", function() { return PermissionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/doctor.service */ "./src/app/services/doctor.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/toast.service */ "./src/app/shared/toast.service.ts");






let PermissionPage = class PermissionPage {
    constructor(api, loadingController, route, router, toastService) {
        this.api = api;
        this.loadingController = loadingController;
        this.route = route;
        this.router = router;
        this.toastService = toastService;
        this.doctor = {};
    }
    ngOnInit() {
        this.getDoctor();
    }
    getDoctor() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: "Loading"
            });
            yield loading.present();
            yield this.api.getDoctorById(this.route.snapshot.paramMap.get('id')).subscribe(res => {
                this.doctor = res.ResponseData;
                loading.dismiss();
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        });
    }
    update() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.api.updateDoctorPermission(this.route.snapshot.paramMap.get('id'), this.doctor)
                .subscribe(res => {
                this.toastService.create("Doctor's permissions are updated");
            }, (err) => {
                console.log(err);
                this.toastService.create(err, 'danger');
            });
        });
    }
};
PermissionPage.ctorParameters = () => [
    { type: src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_2__["DoctorService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"] }
];
PermissionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-permission',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./permission.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/permission/permission.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./permission.page.scss */ "./src/app/members/doctor/permission/permission.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_2__["DoctorService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"]])
], PermissionPage);



/***/ }),

/***/ "./src/app/shared/toast.service.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/toast.service.ts ***!
  \*****************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");



let ToastService = class ToastService {
    constructor(toastCtrl) {
        this.toastCtrl = toastCtrl;
    }
    create(message, color = "success", ok = false, duration = 3000) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.toast) {
                this.toast.dismiss();
            }
            this.toast = yield this.toastCtrl.create({
                message,
                color: color,
                duration: ok ? null : duration,
                position: 'bottom',
            });
            this.toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ })

}]);
//# sourceMappingURL=permission-permission-module-es2015.js.map