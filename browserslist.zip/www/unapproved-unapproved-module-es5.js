function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["unapproved-unapproved-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/unapproved/unapproved.page.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/unapproved/unapproved.page.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersDoctorUnapprovedUnapprovedPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n  <ion-card *ngFor=\"let doc of doctors\">\r\n\r\n    <ion-item>\r\n      <ion-label><b>{{doc.DisplayName}}</b></ion-label>\r\n      <ion-button slot=\"end\" size=\"small\" fill=\"outline\" color=\"tertiary\" (click)=\"onApprove(doc.Id)\">\r\n        Approve &nbsp;\r\n      </ion-button>\r\n    </ion-item>\r\n    <ion-card-content>\r\n      <p>Email: {{ doc.Email}}</p>\r\n      <p>Number: {{doc.MobileNumber}}</p>\r\n      <p>PMDC No: {{doc.PMDC}}</p>\r\n    </ion-card-content>\r\n\r\n  </ion-card>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/members/doctor/unapproved/unapproved.module.ts":
  /*!****************************************************************!*\
    !*** ./src/app/members/doctor/unapproved/unapproved.module.ts ***!
    \****************************************************************/

  /*! exports provided: UnapprovedPageModule */

  /***/
  function srcAppMembersDoctorUnapprovedUnapprovedModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UnapprovedPageModule", function () {
      return UnapprovedPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _unapproved_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./unapproved.page */
    "./src/app/members/doctor/unapproved/unapproved.page.ts");

    var routes = [{
      path: '',
      component: _unapproved_page__WEBPACK_IMPORTED_MODULE_6__["UnapprovedPage"]
    }];

    var UnapprovedPageModule = function UnapprovedPageModule() {
      _classCallCheck(this, UnapprovedPageModule);
    };

    UnapprovedPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_unapproved_page__WEBPACK_IMPORTED_MODULE_6__["UnapprovedPage"]]
    })], UnapprovedPageModule);
    /***/
  },

  /***/
  "./src/app/members/doctor/unapproved/unapproved.page.scss":
  /*!****************************************************************!*\
    !*** ./src/app/members/doctor/unapproved/unapproved.page.scss ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMembersDoctorUnapprovedUnapprovedPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvZG9jdG9yL3VuYXBwcm92ZWQvdW5hcHByb3ZlZC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/members/doctor/unapproved/unapproved.page.ts":
  /*!**************************************************************!*\
    !*** ./src/app/members/doctor/unapproved/unapproved.page.ts ***!
    \**************************************************************/

  /*! exports provided: UnapprovedPage */

  /***/
  function srcAppMembersDoctorUnapprovedUnapprovedPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UnapprovedPage", function () {
      return UnapprovedPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/doctor.service */
    "./src/app/services/doctor.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/toast.service */
    "./src/app/shared/toast.service.ts");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__); //import { LoadingController, Events } from '@ionic/angular';


    var UnapprovedPage = /*#__PURE__*/function () {
      function UnapprovedPage(route, api, loadingController, // public events: Events,
      toastService) {
        _classCallCheck(this, UnapprovedPage);

        this.route = route;
        this.api = api;
        this.loadingController = loadingController;
        this.toastService = toastService;
      }

      _createClass(UnapprovedPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getUnApprovedDoctors();
        }
      }, {
        key: "getUnApprovedDoctors",
        value: function getUnApprovedDoctors() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    _context.next = 7;
                    return this.api.getUnApprovedDoctors().subscribe(function (res) {
                      console.log(res);
                      _this.doctors = res.ResponseData; //   this.events.publish('unapprovedCount', this.doctors.length);

                      loading.dismiss();
                    }, function (err) {
                      console.log(err);
                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "onApprove",
        value: function onApprove(docId) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this2 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context2.sent;
                    _context2.next = 5;
                    return loading.present();

                  case 5:
                    _context2.next = 7;
                    return this.api.approveDoctor(docId).subscribe(function (res) {
                      if (res.IsSuccess) _this2.toastService.create('Doctor\'s approval request succeded');else _this2.toastService.create(res);
                      loading.dismiss();

                      _this2.getUnApprovedDoctors();

                      _this2.getApprovedDoctors();
                    }, function (err) {
                      _this2.toastService.create(err, 'danger');

                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "getApprovedDoctors",
        value: function getApprovedDoctors() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this3 = this;

            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.api.getApprovedDoctors().subscribe(function (res) {
                      console.log(res);
                      _this3.doctors = res.ResponseData; // loop through all date and convert date from 23-12-2012 fomrat to 2012-12-23 format

                      _this3.doctors.forEach(function (doc) {
                        doc.ValidUpto = moment__WEBPACK_IMPORTED_MODULE_6__(doc.ValidUpto, "DD-MM-YYYY").format('YYYY-MM-DD');
                      }); // publish doctors count to update tab's badge in parent page/component
                      // this.events.publish('approvedCount', this.doctors.length);

                    }, function (err) {
                      console.log(err);
                    });

                  case 2:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return UnapprovedPage;
    }();

    UnapprovedPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"]
      }];
    };

    UnapprovedPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-unapproved',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./unapproved.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/unapproved/unapproved.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./unapproved.page.scss */
      "./src/app/members/doctor/unapproved/unapproved.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"], src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"]])], UnapprovedPage);
    /***/
  }
}]);
//# sourceMappingURL=unapproved-unapproved-module-es5.js.map