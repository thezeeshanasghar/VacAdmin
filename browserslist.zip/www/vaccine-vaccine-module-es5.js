function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vaccine-vaccine-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/vaccine.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/vaccine.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersVaccineVaccinePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title> Vaccines</ion-title>\r\n    <ion-item slot=\"end\" color=\"primary\">\r\n      <ion-icon routerLink=\"/members/vaccine/add\" name=\"add\" slot=\"end\" color=\"light\"></ion-icon>\r\n    </ion-item>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n<!-- <ion-searchbar (ionInput)=\"onInput($event)\">\r\n\r\n</ion-searchbar> -->\r\n<ion-content>\r\n\r\n  <ion-card *ngFor=\"let vaccine of vaccines\">\r\n    <ion-item>\r\n      <ion-icon name=\"bandage-outline\" slot=\"start\" style=\"margin-right:16px\"></ion-icon>\r\n      <ion-label><b>{{vaccine.Name}}</b></ion-label>\r\n        <ion-icon  slot=\"end\" routerLink=\"/members/vaccine/edit/{{vaccine.Id}}\" color=\"primary\" name=\"create\" size=\"large\"></ion-icon>\r\n        <ion-icon  slot=\"end\" (click)=\"promptForDeleteVaccine(vaccine.Id)\" color=\"primary\" name=\"trash\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n\r\n    <ion-card-content>\r\n      <p>Minimum Age Limit: <b>{{vaccine.MinAge | number2Week}}</b></p>\r\n      <p *ngIf=\"vaccine.MaxAge\">Maximum Age Limit: <b>{{vaccine.MaxAge | number2Week}}</b></p>\r\n      <ion-button size=\"small\" fill=\"outline\" color=\"tertiary\" routerLink=\"/members/vaccine/{{vaccine.Id}}/doses\">\r\n        Doses &nbsp;\r\n        <ion-badge color=\"primary\">{{vaccine.NumOfDoses}}</ion-badge>\r\n      </ion-button>\r\n      <ion-button size=\"small\" fill=\"outline\" color=\"tertiary\" routerLink=\"/members/vaccine/{{vaccine.Id}}/brands\">\r\n        Brands &nbsp;\r\n        <ion-badge color=\"primary\">{{vaccine.NumOfBrands}}</ion-badge>\r\n      </ion-button>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/members/vaccine/vaccine.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/members/vaccine/vaccine.module.ts ***!
    \***************************************************/

  /*! exports provided: VaccinePageModule */

  /***/
  function srcAppMembersVaccineVaccineModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VaccinePageModule", function () {
      return VaccinePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _vaccine_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./vaccine.page */
    "./src/app/members/vaccine/vaccine.page.ts");
    /* harmony import */


    var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/shared.module */
    "./src/app/shared/shared.module.ts");

    var routes = [{
      path: '',
      component: _vaccine_page__WEBPACK_IMPORTED_MODULE_6__["VaccinePage"]
    }, {
      path: 'add',
      loadChildren: 'src/app/members/vaccine/add/add.module#AddPageModule'
    }, {
      path: 'edit/:id',
      loadChildren: 'src/app/members/vaccine/edit/edit.module#EditPageModule'
    }, {
      path: ':id/doses',
      loadChildren: './dose/dose.module#DosePageModule'
    }, {
      path: ':id/brands',
      loadChildren: './brand/brand.module#BrandPageModule'
    }];

    var VaccinePageModule = function VaccinePageModule() {
      _classCallCheck(this, VaccinePageModule);
    };

    VaccinePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]],
      declarations: [_vaccine_page__WEBPACK_IMPORTED_MODULE_6__["VaccinePage"]]
    })], VaccinePageModule);
    /***/
  },

  /***/
  "./src/app/members/vaccine/vaccine.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/members/vaccine/vaccine.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMembersVaccineVaccinePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvdmFjY2luZS92YWNjaW5lLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/members/vaccine/vaccine.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/members/vaccine/vaccine.page.ts ***!
    \*************************************************/

  /*! exports provided: VaccinePage */

  /***/
  function srcAppMembersVaccineVaccinePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VaccinePage", function () {
      return VaccinePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/vaccine.service */
    "./src/app/services/vaccine.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/alert.service */
    "./src/app/shared/alert.service.ts");
    /* harmony import */


    var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/shared/toast.service */
    "./src/app/shared/toast.service.ts");

    var VaccinePage = /*#__PURE__*/function () {
      function VaccinePage(api, route, router, loadingController, alertService, toastService) {
        _classCallCheck(this, VaccinePage);

        this.api = api;
        this.route = route;
        this.router = router;
        this.loadingController = loadingController;
        this.alertService = alertService;
        this.toastService = toastService; // route.params.subscribe(val => {
        //   this.getVaccines();
        // });
      }

      _createClass(VaccinePage, [{
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.getVaccines();
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {// this.getVaccines();
          // this.checkNetworkStatus();
          // this.storage.get('vaccinedata').then((val) => {
          //   this.vaccines = val;
          // });
        }
      }, {
        key: "getVaccines",
        value: function getVaccines() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    _context.next = 7;
                    return this.api.getVaccines().subscribe(function (res) {
                      _this.vaccines = res.ResponseData;
                      loading.dismiss();
                    }, function (err) {
                      console.log(err);
                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        } // Alert Msg Show for deletion of vaccine

      }, {
        key: "promptForDeleteVaccine",
        value: function promptForDeleteVaccine(id) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this2 = this;

            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    this.alertService.confirmAlert('Are you sure you want to delete this ?', null).then(function (yes) {
                      return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                if (!yes) {
                                  _context2.next = 4;
                                  break;
                                }

                                _context2.next = 3;
                                return this.deleteVaccine(id);

                              case 3:
                                this.getVaccines();

                              case 4:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 1:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        } // Call api to delete a vaccine 

      }, {
        key: "deleteVaccine",
        value: function deleteVaccine(id) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var _this3 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.loadingController.create({
                      message: "Deleting"
                    });

                  case 2:
                    loading = _context4.sent;
                    _context4.next = 5;
                    return loading.present();

                  case 5:
                    _context4.next = 7;
                    return this.api.deleteVaccine(id).subscribe(function (res) {
                      if (!res.IsSuccess) {
                        _this3.alertService.simpleAlert(res.Message);

                        loading.dismiss();
                      } else {
                        _this3.router.navigate(['/members/vaccine']);

                        loading.dismiss();
                      }
                    }, function (err) {
                      console.log(err);
                      console.log("error");
                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "onInput",
        value: function onInput(ev) {
          // set val to the value of the ev target
          var val = ev.target.value; // if the value is an empty string don't filter the items

          if (val && val.trim() != '') {
            this.vaccines = this.vaccines.filter(function (item) {
              return item.Name.toLowerCase().indexOf(val.toLowerCase()) > -1;
            });
          }

          if (val.trim() == "") {
            this.vaccines = this.backupdoctorData;
          }
        }
      }]);

      return VaccinePage;
    }();

    VaccinePage.ctorParameters = function () {
      return [{
        type: src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_2__["VaccineService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"]
      }, {
        type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"]
      }];
    };

    VaccinePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-vaccine',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./vaccine.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/vaccine.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./vaccine.page.scss */
      "./src/app/members/vaccine/vaccine.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_2__["VaccineService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"], src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_5__["AlertService"], src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"]])], VaccinePage);
    /***/
  },

  /***/
  "./src/app/shared/toast.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/shared/toast.service.ts ***!
    \*****************************************/

  /*! exports provided: ToastService */

  /***/
  function srcAppSharedToastServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return ToastService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ToastService = /*#__PURE__*/function () {
      function ToastService(toastCtrl) {
        _classCallCheck(this, ToastService);

        this.toastCtrl = toastCtrl;
      }

      _createClass(ToastService, [{
        key: "create",
        value: function create(message) {
          var color = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "success";
          var ok = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
          var duration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 3000;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    if (this.toast) {
                      this.toast.dismiss();
                    }

                    _context5.next = 3;
                    return this.toastCtrl.create({
                      message: message,
                      color: color,
                      duration: ok ? null : duration,
                      position: 'bottom'
                    });

                  case 3:
                    this.toast = _context5.sent;
                    this.toast.present();

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }]);

      return ToastService;
    }();

    ToastService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])], ToastService);
    /***/
  }
}]);
//# sourceMappingURL=vaccine-vaccine-module-es5.js.map