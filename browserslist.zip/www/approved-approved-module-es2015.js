(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["approved-approved-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/approved/approved.page.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/approved/approved.page.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n\r\n  <ion-card *ngFor=\"let doc of doctors\">\r\n\r\n    <ion-item>\r\n      <ion-label><b>{{doc.DisplayName}}</b></ion-label>\r\n      <ion-datetime slot=\"end\"\r\n        slot=\"end\" \r\n        min=\"2015\"\r\n        max=\"2030\"\r\n        size=\"small\" \r\n        display-format=\"MMM YYYY\" \r\n        picker-format=\"DD MMM YYYY\" \r\n        value=\"{{doc.ValidUpto}}\" \r\n        class=\"success\"\r\n        [ngClass]=\"{fail: doc.ValidUpto < today}\"\r\n        (ionChange)=\"updateValidity($event, doc.Id)\"\r\n      ></ion-datetime>\r\n    </ion-item>\r\n    <ion-card-content>\r\n      <p>Email: {{ doc.Email}}</p>\r\n      <p>Number: {{doc.MobileNumber}}</p>\r\n      <p>PMDC No: {{doc.PMDC}}</p>\r\n      <ion-button size=\"small\" fill=\"outline\" color=\"tertiary\" routerLink=\"/members/doctor/{{doc.Id}}/permissions\">\r\n        <ion-icon name=\"finger-print\"></ion-icon>\r\n        Permissions\r\n      </ion-button>\r\n      <ion-button size=\"small\" disabled=\"true\" fill=\"outline\" color=\"tertiary\" routerLink=\"/members/doctor/{{doc.Id}}/permissions\">\r\n        <ion-icon name=\"body\"></ion-icon>\r\n        Patients\r\n      </ion-button>\r\n    </ion-card-content>\r\n\r\n  </ion-card>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/members/doctor/approved/approved.module.ts":
/*!************************************************************!*\
  !*** ./src/app/members/doctor/approved/approved.module.ts ***!
  \************************************************************/
/*! exports provided: ApprovedPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApprovedPageModule", function() { return ApprovedPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _approved_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./approved.page */ "./src/app/members/doctor/approved/approved.page.ts");







const routes = [
    {
        path: '',
        component: _approved_page__WEBPACK_IMPORTED_MODULE_6__["ApprovedPage"]
    }
];
let ApprovedPageModule = class ApprovedPageModule {
};
ApprovedPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_approved_page__WEBPACK_IMPORTED_MODULE_6__["ApprovedPage"]]
    })
], ApprovedPageModule);



/***/ }),

/***/ "./src/app/members/doctor/approved/approved.page.scss":
/*!************************************************************!*\
  !*** ./src/app/members/doctor/approved/approved.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".success {\n  color: green;\n}\n\n.fail {\n  color: red;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVtYmVycy9kb2N0b3IvYXBwcm92ZWQvRTpcXE5ldyBmb2xkZXJcXFZhY0FkbWluL3NyY1xcYXBwXFxtZW1iZXJzXFxkb2N0b3JcXGFwcHJvdmVkXFxhcHByb3ZlZC5wYWdlLnNjc3MiLCJzcmMvYXBwL21lbWJlcnMvZG9jdG9yL2FwcHJvdmVkL2FwcHJvdmVkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUNDSjs7QURDQTtFQUNJLFVBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvZG9jdG9yL2FwcHJvdmVkL2FwcHJvdmVkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWNjZXNzIHtcclxuICAgIGNvbG9yOiBncmVlblxyXG59XHJcbi5mYWlsIHtcclxuICAgIGNvbG9yOnJlZFxyXG59IiwiLnN1Y2Nlc3Mge1xuICBjb2xvcjogZ3JlZW47XG59XG5cbi5mYWlsIHtcbiAgY29sb3I6IHJlZDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/members/doctor/approved/approved.page.ts":
/*!**********************************************************!*\
  !*** ./src/app/members/doctor/approved/approved.page.ts ***!
  \**********************************************************/
/*! exports provided: ApprovedPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApprovedPage", function() { return ApprovedPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/doctor.service */ "./src/app/services/doctor.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/toast.service */ "./src/app/shared/toast.service.ts");




//import { LoadingController, Events } from '@ionic/angular';



let ApprovedPage = class ApprovedPage {
    constructor(route, api, loadingController, 
    //  private events: Events,
    toastService) {
        this.route = route;
        this.api = api;
        this.loadingController = loadingController;
        this.toastService = toastService;
        this.today = moment__WEBPACK_IMPORTED_MODULE_5__().format('YYYY-MM-DD');
    }
    ngOnInit() {
        this.getApprovedDoctors();
    }
    getApprovedDoctors() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Loading'
            });
            yield loading.present();
            yield this.api.getApprovedDoctors().subscribe(res => {
                console.log(res);
                this.doctors = res.ResponseData;
                // loop through all date and convert date from 23-12-2012 fomrat to 2012-12-23 format
                this.doctors.forEach(doc => {
                    doc.ValidUpto = moment__WEBPACK_IMPORTED_MODULE_5__(doc.ValidUpto, "DD-MM-YYYY").format('YYYY-MM-DD');
                });
                // publish doctors count to update tab's badge in parent page/component
                //  this.events.publish('approvedCount', this.doctors.length);
                loading.dismiss();
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        });
    }
    updateValidity($event, docID) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({ message: 'Loading' });
            yield loading.present();
            let newDate = $event.detail.value;
            newDate = moment__WEBPACK_IMPORTED_MODULE_5__(newDate, 'YYYY-MM-DD').format('DD-MM-YYYY');
            this.api.changeValidity(newDate, docID).subscribe(res => {
                if (res.IsSuccess)
                    this.toastService.create('Doctor\'s validity change successfully.');
                else
                    this.toastService.create(res.Message, 'danger');
                loading.dismiss();
            }, err => {
                this.toastService.create(err, 'danger');
                loading.dismiss();
            });
        });
    }
};
ApprovedPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"] }
];
ApprovedPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-approved',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./approved.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/doctor/approved/approved.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./approved.page.scss */ "./src/app/members/doctor/approved/approved.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        src_app_services_doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"],
        src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"]])
], ApprovedPage);



/***/ })

}]);
//# sourceMappingURL=approved-approved-module-es2015.js.map