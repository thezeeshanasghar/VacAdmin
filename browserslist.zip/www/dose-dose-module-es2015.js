(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["dose-dose-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/dose.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/dose.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/members/dashboard\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Vaccine Dosses</ion-title>\r\n    <ion-item slot=\"end\" color=\"primary\">\r\n      <ion-icon routerLink=\"/members/vaccine/{{vaccineId}}/doses/add\" name=\"add\" slot=\"end\" color=\"light\"></ion-icon>\r\n    </ion-item>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n  <ion-card *ngFor=\"let d of dosses\">\r\n    <ion-item>\r\n      <ion-label>{{d.Name}}</ion-label>\r\n\r\n      <ion-item slot=\"end\">\r\n        <ion-icon color=\"primary\" name=\"create\" routerLink=\"/members/vaccine/{{vaccineId}}/doses/edit/{{d.Id}}\"></ion-icon>\r\n        <ion-icon (click)=\"alertDeleteDose(d.Id)\" color=\"primary\" name=\"trash\"></ion-icon>\r\n      </ion-item>\r\n    </ion-item>\r\n\r\n    <ion-card-content>\r\n      <!-- <ion-card-subtitle>Details:</ion-card-subtitle> -->\r\n      <p>Minimum Age Limit: {{d.MinAge | number2Week}}</p>\r\n      <p *ngIf=\"d.MaxAge\">Maximum Age Limit: {{d.MaxAge | number2Week}}</p>\r\n      <p *ngIf=\"d.MaxGap\">Max Gap: {{d.MaxGap | number2Week}}</p>\r\n      <p>Dose Order: {{d.DoseOrder}}</p>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n</ion-content>");

/***/ }),

/***/ "./src/app/members/vaccine/dose/dose.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/members/vaccine/dose/dose.module.ts ***!
  \*****************************************************/
/*! exports provided: DosePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DosePageModule", function() { return DosePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _dose_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dose.page */ "./src/app/members/vaccine/dose/dose.page.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");








const routes = [
    {
        path: '',
        component: _dose_page__WEBPACK_IMPORTED_MODULE_6__["DosePage"]
    },
    { path: 'add', loadChildren: 'src/app/members/vaccine/dose/add/add.module#AddPageModule' },
    { path: 'edit/:id1', loadChildren: 'src/app/members/vaccine/dose/edit/edit.module#EditPageModule' },
];
let DosePageModule = class DosePageModule {
};
DosePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]
        ],
        declarations: [_dose_page__WEBPACK_IMPORTED_MODULE_6__["DosePage"]]
    })
], DosePageModule);



/***/ }),

/***/ "./src/app/members/vaccine/dose/dose.page.ts":
/*!***************************************************!*\
  !*** ./src/app/members/vaccine/dose/dose.page.ts ***!
  \***************************************************/
/*! exports provided: DosePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DosePage", function() { return DosePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/dose.service */ "./src/app/services/dose.service.ts");
/* harmony import */ var src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/vaccine.service */ "./src/app/services/vaccine.service.ts");
/* harmony import */ var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/toast.service */ "./src/app/shared/toast.service.ts");
/* harmony import */ var src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/alert.service */ "./src/app/shared/alert.service.ts");








let DosePage = class DosePage {
    constructor(route, api, vaccineAPI, loadingController, router, toast, alertService) {
        this.route = route;
        this.api = api;
        this.vaccineAPI = vaccineAPI;
        this.loadingController = loadingController;
        this.router = router;
        this.toast = toast;
        this.alertService = alertService;
    }
    ionViewWillEnter() {
        this.vaccineId = this.route.snapshot.paramMap.get('id');
        this.getDosses();
    }
    // Get all dosses base on vaccineID from server
    getDosses() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Loading'
            });
            yield loading.present();
            yield this.vaccineAPI.getDosesByVaccineId(this.route.snapshot.paramMap.get('id')).subscribe(res => {
                console.log(res);
                this.dosses = res.ResponseData;
                loading.dismiss();
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        });
    }
    // Alert Msg Show for deletion of Dose
    alertDeleteDose(id) {
        this.alertService.confirmAlert('Are you sure you want to delete this ?', null)
            .then((yes) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (yes) {
                yield this.deleteDose(id);
                this.getDosses();
            }
        }));
    }
    // Call api to delete a vaccine 
    deleteDose(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: "Deleting"
            });
            yield loading.present();
            yield this.api.deleteDose(id).subscribe(res => {
                console.log(res);
                if (!res.IsSuccess) {
                    loading.dismiss();
                }
                else {
                    this.router.navigateByUrl('/vaccine/' + this.route.snapshot.paramMap.get('id') + '/dose');
                    loading.dismiss();
                }
            }, err => {
                this.toast.create(err);
                loading.dismiss();
            });
        });
    }
};
DosePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_4__["DoseService"] },
    { type: src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_5__["VaccineService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"] },
    { type: src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"] }
];
DosePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-dose',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./dose.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/dose.page.html")).default
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_4__["DoseService"],
        src_app_services_vaccine_service__WEBPACK_IMPORTED_MODULE_5__["VaccineService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"],
        src_app_shared_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"]])
], DosePage);



/***/ }),

/***/ "./src/app/shared/toast.service.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/toast.service.ts ***!
  \*****************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");



let ToastService = class ToastService {
    constructor(toastCtrl) {
        this.toastCtrl = toastCtrl;
    }
    create(message, color = "success", ok = false, duration = 3000) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.toast) {
                this.toast.dismiss();
            }
            this.toast = yield this.toastCtrl.create({
                message,
                color: color,
                duration: ok ? null : duration,
                position: 'bottom',
            });
            this.toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ })

}]);
//# sourceMappingURL=dose-dose-module-es2015.js.map