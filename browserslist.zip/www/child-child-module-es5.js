function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { return function () { var Super = _getPrototypeOf(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["child-child-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/child/child.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/child/child.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersChildChildPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Patients</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form padding [formGroup]=\"loginForm\" (ngSubmit)=\"onSubmit()\">\r\n    <!-- city search dropdown -->\r\n    <ion-item>\r\n      <ion-label position=\"fixed\" color=\"primary\">City</ion-label>\r\n      <ion-select formControlName=\"city\" multiple=\"false\" placeholder=\"Select City\">\r\n          <ion-select-option value=\"\" >Any</ion-select-option>\r\n        <ion-select-option value=\"Abbottabad\">Abbottabad</ion-select-option>\r\n        <ion-select-option value=\"Adezai\">Adezai</ion-select-option>\r\n        <ion-select-option value=\"Ali Bandar\">Ali Bandar</ion-select-option>\r\n        <ion-select-option value=\"Amir Chah\">Amir Chah</ion-select-option>\r\n        <ion-select-option value=\"Attock\">Attock</ion-select-option>\r\n        <ion-select-option value=\"Ayubia\">Ayubia</ion-select-option>\r\n        <ion-select-option value=\"Bahawalpur\">Bahawalpur</ion-select-option>\r\n        <ion-select-option value=\"Baden\">Baden</ion-select-option>\r\n        <ion-select-option value=\"Bagh\">Bagh</ion-select-option>\r\n        <ion-select-option value=\"Bahawalnagar\">Bahawalnagar</ion-select-option>\r\n        <ion-select-option value=\"Burewala\">Burewala</ion-select-option>\r\n        <ion-select-option value=\"Banda Daud Shah\">Banda Daud Shah</ion-select-option>\r\n        <ion-select-option value=\"Bannu district|Bannu\">Bannu</ion-select-option>\r\n        <ion-select-option value=\"Batagram\">Batagram</ion-select-option>\r\n        <ion-select-option value=\"Bazdar\">Bazdar</ion-select-option>\r\n        <ion-select-option value=\"Bela\">Bela</ion-select-option>\r\n        <ion-select-option value=\"Bellpat\">Bellpat</ion-select-option>\r\n        <ion-select-option value=\"Bhag\">Bhag</ion-select-option>\r\n        <ion-select-option value=\"Bhakkar\">Bhakkar</ion-select-option>\r\n        <ion-select-option value=\"Bhalwal\">Bhalwal</ion-select-option>\r\n        <ion-select-option value=\"Bhimber\">Bhimber</ion-select-option>\r\n        <ion-select-option value=\"Birote\">Birote</ion-select-option>\r\n        <ion-select-option value=\"Buner\">Buner</ion-select-option>\r\n        <ion-select-option value=\"Burj\">Burj</ion-select-option>\r\n        <ion-select-option value=\"Chiniot\">Chiniot</ion-select-option>\r\n        <ion-select-option value=\"Chachro\">Chachro</ion-select-option>\r\n        <ion-select-option value=\"Chagai\">Chagai</ion-select-option>\r\n        <ion-select-option value=\"Chah Sandan\">Chah Sandan</ion-select-option>\r\n        <ion-select-option value=\"Chailianwala\">Chailianwala</ion-select-option>\r\n        <ion-select-option value=\"Chakdara\">Chakdara</ion-select-option>\r\n        <ion-select-option value=\"Chakku\">Chakku</ion-select-option>\r\n        <ion-select-option value=\"Chakwal\">Chakwal</ion-select-option>\r\n        <ion-select-option value=\"Chaman\">Chaman</ion-select-option>\r\n        <ion-select-option value=\"Charsadda\">Charsadda</ion-select-option>\r\n        <ion-select-option value=\"Chhatr\">Chhatr</ion-select-option>\r\n        <ion-select-option value=\"Chichawatni\">Chichawatni</ion-select-option>\r\n        <ion-select-option value=\"Chitral\">Chitral</ion-select-option>\r\n        <ion-select-option value=\"Dadu\">Dadu</ion-select-option>\r\n        <ion-select-option value=\"Dera Ghazi Khan\">Dera Ghazi Khan</ion-select-option>\r\n        <ion-select-option value=\"Dera Ismail Khan\">Dera Ismail Khan</ion-select-option>\r\n        <ion-select-option value=\"Dalbandin\">Dalbandin</ion-select-option>\r\n        <ion-select-option value=\"Dargai\">Dargai</ion-select-option>\r\n        <ion-select-option value=\"Darya Khan\">Darya Khan</ion-select-option>\r\n        <ion-select-option value=\"Daska\">Daska</ion-select-option>\r\n        <ion-select-option value=\"Dera Bugti\">Dera Bugti</ion-select-option>\r\n        <ion-select-option value=\"Dhana Sar\">Dhana Sar</ion-select-option>\r\n        <ion-select-option value=\"Digri\">Digri</ion-select-option>\r\n        <ion-select-option value=\"Dina City|Dina\">Dina</ion-select-option>\r\n        <ion-select-option value=\"Dinga\">Dinga</ion-select-option>\r\n        <ion-select-option value=\"Diplo, Pakistan|Diplo\">Diplo</ion-select-option>\r\n        <ion-select-option value=\"Diwana\">Diwana</ion-select-option>\r\n        <ion-select-option value=\"Dokri\">Dokri</ion-select-option>\r\n        <ion-select-option value=\"Drosh\">Drosh</ion-select-option>\r\n        <ion-select-option value=\"Duki\">Duki</ion-select-option>\r\n        <ion-select-option value=\"Dushi\">Dushi</ion-select-option>\r\n        <ion-select-option value=\"Duzab\">Duzab</ion-select-option>\r\n        <ion-select-option value=\"Faisalabad\">Faisalabad</ion-select-option>\r\n        <ion-select-option value=\"Fateh Jang\">Fateh Jang</ion-select-option>\r\n        <ion-select-option value=\"Ghotki\">Ghotki</ion-select-option>\r\n        <ion-select-option value=\"Gwadar\">Gwadar</ion-select-option>\r\n        <ion-select-option value=\"Gujranwala\">Gujranwala</ion-select-option>\r\n        <ion-select-option value=\"Gujrat\">Gujrat</ion-select-option>\r\n        <ion-select-option value=\"Gadra\">Gadra</ion-select-option>\r\n        <ion-select-option value=\"Gajar\">Gajar</ion-select-option>\r\n        <ion-select-option value=\"Gandava\">Gandava</ion-select-option>\r\n        <ion-select-option value=\"Garhi Khairo\">Garhi Khairo</ion-select-option>\r\n        <ion-select-option value=\"Garruck\">Garruck</ion-select-option>\r\n        <ion-select-option value=\"Ghakhar Mandi\">Ghakhar Mandi</ion-select-option>\r\n        <ion-select-option value=\"Ghanian\">Ghanian</ion-select-option>\r\n        <ion-select-option value=\"Ghauspur\">Ghauspur</ion-select-option>\r\n        <ion-select-option value=\"Ghazluna\">Ghazluna</ion-select-option>\r\n        <ion-select-option value=\"Girdan\">Girdan</ion-select-option>\r\n        <ion-select-option value=\"Gulistan\">Gulistan</ion-select-option>\r\n        <ion-select-option value=\"Gwash\">Gwash</ion-select-option>\r\n        <ion-select-option value=\"Hyderabad\">Hyderabad</ion-select-option>\r\n        <ion-select-option value=\"Hala\">Hala</ion-select-option>\r\n        <ion-select-option value=\"Haripur\">Haripur</ion-select-option>\r\n        <ion-select-option value=\"Hab Chauki\">Hab Chauki</ion-select-option>\r\n        <ion-select-option value=\"Hafizabad\">Hafizabad</ion-select-option>\r\n        <ion-select-option value=\"Hameedabad\">Hameedabad</ion-select-option>\r\n        <ion-select-option value=\"Hangu\">Hangu</ion-select-option>\r\n        <ion-select-option value=\"Harnai\">Harnai</ion-select-option>\r\n        <ion-select-option value=\"Hasilpur\">Hasilpur</ion-select-option>\r\n        <ion-select-option value=\"Haveli Lakha\">Haveli Lakha</ion-select-option>\r\n        <ion-select-option value=\"Hinglaj\">Hinglaj</ion-select-option>\r\n        <ion-select-option value=\"Hoshab\">Hoshab</ion-select-option>\r\n        <ion-select-option value=\"Islamabad\">Islamabad</ion-select-option>\r\n        <ion-select-option value=\"Islamkot\">Islamkot</ion-select-option>\r\n        <ion-select-option value=\"Ispikan\">Ispikan</ion-select-option>\r\n        <ion-select-option value=\"Jacobabad\">Jacobabad</ion-select-option>\r\n        <ion-select-option value=\"Jamshoro\">Jamshoro</ion-select-option>\r\n        <ion-select-option value=\"Jhang\">Jhang</ion-select-option>\r\n        <ion-select-option value=\"Jhelum\">Jhelum</ion-select-option>\r\n        <ion-select-option value=\"Jamesabad\">Jamesabad</ion-select-option>\r\n        <ion-select-option value=\"Jampur\">Jampur</ion-select-option>\r\n        <ion-select-option value=\"Janghar\">Janghar</ion-select-option>\r\n        <ion-select-option value=\"Jati, Jati(Mughalbhin)\">Jati</ion-select-option>\r\n        <ion-select-option value=\"Jauharabad\">Jauharabad</ion-select-option>\r\n        <ion-select-option value=\"Jhal\">Jhal</ion-select-option>\r\n        <ion-select-option value=\"Jhal Jhao\">Jhal Jhao</ion-select-option>\r\n        <ion-select-option value=\"Jhatpat\">Jhatpat</ion-select-option>\r\n        <ion-select-option value=\"Jhudo\">Jhudo</ion-select-option>\r\n        <ion-select-option value=\"Jiwani\">Jiwani</ion-select-option>\r\n        <ion-select-option value=\"Jungshahi\">Jungshahi</ion-select-option>\r\n        <ion-select-option value=\"Karachi\">Karachi</ion-select-option>\r\n        <ion-select-option value=\"Kotri\">Kotri</ion-select-option>\r\n        <ion-select-option value=\"Kalam\">Kalam</ion-select-option>\r\n        <ion-select-option value=\"Kalandi\">Kalandi</ion-select-option>\r\n        <ion-select-option value=\"Kalat\">Kalat</ion-select-option>\r\n        <ion-select-option value=\"Kamalia\">Kamalia</ion-select-option>\r\n        <ion-select-option value=\"Kamararod\">Kamararod</ion-select-option>\r\n        <ion-select-option value=\"Kamber\">Kamber</ion-select-option>\r\n        <ion-select-option value=\"Kamokey\">Kamokey</ion-select-option>\r\n        <ion-select-option value=\"Kanak\">Kanak</ion-select-option>\r\n        <ion-select-option value=\"Kandi\">Kandi</ion-select-option>\r\n        <ion-select-option value=\"Kandiaro\">Kandiaro</ion-select-option>\r\n        <ion-select-option value=\"Kanpur\">Kanpur</ion-select-option>\r\n        <ion-select-option value=\"Kapip\">Kapip</ion-select-option>\r\n        <ion-select-option value=\"Kappar\">Kappar</ion-select-option>\r\n        <ion-select-option value=\"Karak City\">Karak City</ion-select-option>\r\n        <ion-select-option value=\"Karodi\">Karodi</ion-select-option>\r\n        <ion-select-option value=\"Kashmor\">Kashmor</ion-select-option>\r\n        <ion-select-option value=\"Kasur\">Kasur</ion-select-option>\r\n        <ion-select-option value=\"Katuri\">Katuri</ion-select-option>\r\n        <ion-select-option value=\"Keti Bandar\">Keti Bandar</ion-select-option>\r\n        <ion-select-option value=\"Khairpur\">Khairpur</ion-select-option>\r\n        <ion-select-option value=\"Khanaspur\">Khanaspur</ion-select-option>\r\n        <ion-select-option value=\"Khanewal\">Khanewal</ion-select-option>\r\n        <ion-select-option value=\"Kharan\">Kharan</ion-select-option>\r\n        <ion-select-option value=\"kharian\">kharian</ion-select-option>\r\n        <ion-select-option value=\"Khokhropur\">Khokhropur</ion-select-option>\r\n        <ion-select-option value=\"Khora\">Khora</ion-select-option>\r\n        <ion-select-option value=\"Khushab\">Khushab</ion-select-option>\r\n        <ion-select-option value=\"Khuzdar\">Khuzdar</ion-select-option>\r\n        <ion-select-option value=\"Kikki\">Kikki</ion-select-option>\r\n        <ion-select-option value=\"Klupro\">Klupro</ion-select-option>\r\n        <ion-select-option value=\"Kohan\">Kohan</ion-select-option>\r\n        <ion-select-option value=\"Kohat\">Kohat</ion-select-option>\r\n        <ion-select-option value=\"Kohistan\">Kohistan</ion-select-option>\r\n        <ion-select-option value=\"Kohlu\">Kohlu</ion-select-option>\r\n        <ion-select-option value=\"Korak\">Korak</ion-select-option>\r\n        <ion-select-option value=\"Korangi\">Korangi</ion-select-option>\r\n        <ion-select-option value=\"Kot Sarae\">Kot Sarae</ion-select-option>\r\n        <ion-select-option value=\"Kotli\">Kotli</ion-select-option>\r\n        <ion-select-option value=\"Lahore\">Lahore</ion-select-option>\r\n        <ion-select-option value=\"Larkana\">Larkana</ion-select-option>\r\n        <ion-select-option value=\"Lahri\">Lahri</ion-select-option>\r\n        <ion-select-option value=\"Lakki Marwat\">Lakki Marwat</ion-select-option>\r\n        <ion-select-option value=\"Lasbela\">Lasbela</ion-select-option>\r\n        <ion-select-option value=\"Latamber\">Latamber</ion-select-option>\r\n        <ion-select-option value=\"Layyah\">Layyah</ion-select-option>\r\n        <ion-select-option value=\"Leiah\">Leiah</ion-select-option>\r\n        <ion-select-option value=\"Liari\">Liari</ion-select-option>\r\n        <ion-select-option value=\"Lodhran\">Lodhran</ion-select-option>\r\n        <ion-select-option value=\"Loralai\">Loralai</ion-select-option>\r\n        <ion-select-option value=\"Lower Dir\">Lower Dir</ion-select-option>\r\n        <ion-select-option value=\"Shadan Lund\">Shadan Lund</ion-select-option>\r\n        <ion-select-option value=\"Multan\">Multan</ion-select-option>\r\n        <ion-select-option value=\"Mandi Bahauddin\">Mandi Bahauddin</ion-select-option>\r\n        <ion-select-option value=\"Mansehra\">Mansehra</ion-select-option>\r\n        <ion-select-option value=\"Mian Chanu\">Mian Chanu</ion-select-option>\r\n        <ion-select-option value=\"Mirpur\">Mirpur</ion-select-option>\r\n        <ion-select-option value=\"Moro, Pakistan|Moro\">Moro</ion-select-option>\r\n        <ion-select-option value=\"Mardan\">Mardan</ion-select-option>\r\n        <ion-select-option value=\"Mach\">Mach</ion-select-option>\r\n        <ion-select-option value=\"Madyan\">Madyan</ion-select-option>\r\n        <ion-select-option value=\"Malakand\">Malakand</ion-select-option>\r\n        <ion-select-option value=\"Mand\">Mand</ion-select-option>\r\n        <ion-select-option value=\"Manguchar\">Manguchar</ion-select-option>\r\n        <ion-select-option value=\"Mashki Chah\">Mashki Chah</ion-select-option>\r\n        <ion-select-option value=\"Maslti\">Maslti</ion-select-option>\r\n        <ion-select-option value=\"Mastuj\">Mastuj</ion-select-option>\r\n        <ion-select-option value=\"Mastung\">Mastung</ion-select-option>\r\n        <ion-select-option value=\"Mathi\">Mathi</ion-select-option>\r\n        <ion-select-option value=\"Matiari\">Matiari</ion-select-option>\r\n        <ion-select-option value=\"Mehar\">Mehar</ion-select-option>\r\n        <ion-select-option value=\"Mekhtar\">Mekhtar</ion-select-option>\r\n        <ion-select-option value=\"Merui\">Merui</ion-select-option>\r\n        <ion-select-option value=\"Mianwali\">Mianwali</ion-select-option>\r\n        <ion-select-option value=\"Mianez\">Mianez</ion-select-option>\r\n        <ion-select-option value=\"Mirpur Batoro\">Mirpur Batoro</ion-select-option>\r\n        <ion-select-option value=\"Mirpur Khas\">Mirpur Khas</ion-select-option>\r\n        <ion-select-option value=\"Mirpur Sakro\">Mirpur Sakro</ion-select-option>\r\n        <ion-select-option value=\"Mithi\">Mithi</ion-select-option>\r\n        <ion-select-option value=\"Mongora\">Mongora</ion-select-option>\r\n        <ion-select-option value=\"Murgha Kibzai\">Murgha Kibzai</ion-select-option>\r\n        <ion-select-option value=\"Muridke\">Muridke</ion-select-option>\r\n        <ion-select-option value=\"Musa Khel Bazar\">Musa Khel Bazar</ion-select-option>\r\n        <ion-select-option value=\"Muzaffar Garh\">Muzaffar Garh</ion-select-option>\r\n        <ion-select-option value=\"Muzaffarabad\">Muzaffarabad</ion-select-option>\r\n        <ion-select-option value=\"Nawabshah\">Nawabshah</ion-select-option>\r\n        <ion-select-option value=\"Nazimabad\">Nazimabad</ion-select-option>\r\n        <ion-select-option value=\"Nowshera\">Nowshera</ion-select-option>\r\n        <ion-select-option value=\"Nagar Parkar\">Nagar Parkar</ion-select-option>\r\n        <ion-select-option value=\"Nagha Kalat\">Nagha Kalat</ion-select-option>\r\n        <ion-select-option value=\"Nal\">Nal</ion-select-option>\r\n        <ion-select-option value=\"Naokot\">Naokot</ion-select-option>\r\n        <ion-select-option value=\"Nasirabad\">Nasirabad</ion-select-option>\r\n        <ion-select-option value=\"Nauroz Kalat\">Nauroz Kalat</ion-select-option>\r\n        <ion-select-option value=\"Naushara\">Naushara</ion-select-option>\r\n        <ion-select-option value=\"Nur Gamma\">Nur Gamma</ion-select-option>\r\n        <ion-select-option value=\"Nushki\">Nushki</ion-select-option>\r\n        <ion-select-option value=\"Nuttal\">Nuttal</ion-select-option>\r\n        <ion-select-option value=\"Okara\">Okara</ion-select-option>\r\n        <ion-select-option value=\"Ormara\">Ormara</ion-select-option>\r\n        <ion-select-option value=\"Peshawar\">Peshawar</ion-select-option>\r\n        <ion-select-option value=\"Panjgur\">Panjgur</ion-select-option>\r\n        <ion-select-option value=\"Pasni City\">Pasni City</ion-select-option>\r\n        <ion-select-option value=\"Paharpur\">Paharpur</ion-select-option>\r\n        <ion-select-option value=\"Palantuk\">Palantuk</ion-select-option>\r\n        <ion-select-option value=\"Pendoo\">Pendoo</ion-select-option>\r\n        <ion-select-option value=\"Piharak\">Piharak</ion-select-option>\r\n        <ion-select-option value=\"Pirmahal\">Pirmahal</ion-select-option>\r\n        <ion-select-option value=\"Pishin\">Pishin</ion-select-option>\r\n        <ion-select-option value=\"Plandri\">Plandri</ion-select-option>\r\n        <ion-select-option value=\"Pokran\">Pokran</ion-select-option>\r\n        <ion-select-option value=\"Pounch\">Pounch</ion-select-option>\r\n        <ion-select-option value=\"Quetta\">Quetta</ion-select-option>\r\n        <ion-select-option value=\"Qambar\">Qambar</ion-select-option>\r\n        <ion-select-option value=\"Qamruddin Karez\">Qamruddin Karez</ion-select-option>\r\n        <ion-select-option value=\"Qazi Ahmad\">Qazi Ahmad</ion-select-option>\r\n        <ion-select-option value=\"Qila Abdullah\">Qila Abdullah</ion-select-option>\r\n        <ion-select-option value=\"Qila Ladgasht\">Qila Ladgasht</ion-select-option>\r\n        <ion-select-option value=\"Qila Safed\">Qila Safed</ion-select-option>\r\n        <ion-select-option value=\"Qila Saifullah\">Qila Saifullah</ion-select-option>\r\n        <ion-select-option value=\"Rawalpindi\">Rawalpindi</ion-select-option>\r\n        <ion-select-option value=\"Rabwah\">Rabwah</ion-select-option>\r\n        <ion-select-option value=\"Rahim Yar Khan\">Rahim Yar Khan</ion-select-option>\r\n        <ion-select-option value=\"Rajan Pur\">Rajan Pur</ion-select-option>\r\n        <ion-select-option value=\"Rakhni\">Rakhni</ion-select-option>\r\n        <ion-select-option value=\"Ranipur\">Ranipur</ion-select-option>\r\n        <ion-select-option value=\"Ratodero\">Ratodero</ion-select-option>\r\n        <ion-select-option value=\"Rawalakot\">Rawalakot</ion-select-option>\r\n        <ion-select-option value=\"Renala Khurd\">Renala Khurd</ion-select-option>\r\n        <ion-select-option value=\"Robat Thana\">Robat Thana</ion-select-option>\r\n        <ion-select-option value=\"Rodkhan\">Rodkhan</ion-select-option>\r\n        <ion-select-option value=\"Rohri\">Rohri</ion-select-option>\r\n        <ion-select-option value=\"Sialkot\">Sialkot</ion-select-option>\r\n        <ion-select-option value=\"Sadiqabad\">Sadiqabad</ion-select-option>\r\n        <ion-select-option value=\"Safdar Abad- (Dhaban Singh)\">Safdar Abad</ion-select-option>\r\n        <ion-select-option value=\"Sahiwal\">Sahiwal</ion-select-option>\r\n        <ion-select-option value=\"Saidu Sharif\">Saidu Sharif</ion-select-option>\r\n        <ion-select-option value=\"Saindak\">Saindak</ion-select-option>\r\n        <ion-select-option value=\"Sakrand\">Sakrand</ion-select-option>\r\n        <ion-select-option value=\"Sanjawi\">Sanjawi</ion-select-option>\r\n        <ion-select-option value=\"Sargodha\">Sargodha</ion-select-option>\r\n        <ion-select-option value=\"Saruna\">Saruna</ion-select-option>\r\n        <ion-select-option value=\"Shabaz Kalat\">Shabaz Kalat</ion-select-option>\r\n        <ion-select-option value=\"Shadadkhot\">Shadadkhot</ion-select-option>\r\n        <ion-select-option value=\"Shahbandar\">Shahbandar</ion-select-option>\r\n        <ion-select-option value=\"Shahpur\">Shahpur</ion-select-option>\r\n        <ion-select-option value=\"Shahpur Chakar\">Shahpur Chakar</ion-select-option>\r\n        <ion-select-option value=\"Shakargarh\">Shakargarh</ion-select-option>\r\n        <ion-select-option value=\"Shangla\">Shangla</ion-select-option>\r\n        <ion-select-option value=\"Sharam Jogizai\">Sharam Jogizai</ion-select-option>\r\n        <ion-select-option value=\"Sheikhupura\">Sheikhupura</ion-select-option>\r\n        <ion-select-option value=\"Shikarpur\">Shikarpur</ion-select-option>\r\n        <ion-select-option value=\"Shingar\">Shingar</ion-select-option>\r\n        <ion-select-option value=\"Shorap\">Shorap</ion-select-option>\r\n        <ion-select-option value=\"Sibi\">Sibi</ion-select-option>\r\n        <ion-select-option value=\"Sohawa\">Sohawa</ion-select-option>\r\n        <ion-select-option value=\"Sonmiani\">Sonmiani</ion-select-option>\r\n        <ion-select-option value=\"Sooianwala\">Sooianwala</ion-select-option>\r\n        <ion-select-option value=\"Spezand\">Spezand</ion-select-option>\r\n        <ion-select-option value=\"Spintangi\">Spintangi</ion-select-option>\r\n        <ion-select-option value=\"Sui\">Sui</ion-select-option>\r\n        <ion-select-option value=\"Sujawal\">Sujawal</ion-select-option>\r\n        <ion-select-option value=\"Sukkur\">Sukkur</ion-select-option>\r\n        <ion-select-option value=\"Suntsar\">Suntsar</ion-select-option>\r\n        <ion-select-option value=\"Surab\">Surab</ion-select-option>\r\n        <ion-select-option value=\"Swabi\">Swabi</ion-select-option>\r\n        <ion-select-option value=\"Swat\">Swat</ion-select-option>\r\n        <ion-select-option value=\"Tando Adam\">Tando Adam</ion-select-option>\r\n        <ion-select-option value=\"Tando Bago\">Tando Bago</ion-select-option>\r\n        <ion-select-option value=\"Tangi\">Tangi</ion-select-option>\r\n        <ion-select-option value=\"Tank City\">Tank City</ion-select-option>\r\n        <ion-select-option value=\"Tar Ahamd Rind\">Tar Ahamd Rind</ion-select-option>\r\n        <ion-select-option value=\"Thalo\">Thalo</ion-select-option>\r\n        <ion-select-option value=\"Thatta\">Thatta</ion-select-option>\r\n        <ion-select-option value=\"Toba Tek Singh\">Toba Tek Singh</ion-select-option>\r\n        <ion-select-option value=\"Tordher\">Tordher</ion-select-option>\r\n        <ion-select-option value=\"Tujal\">Tujal</ion-select-option>\r\n        <ion-select-option value=\"Tump\">Tump</ion-select-option>\r\n        <ion-select-option value=\"Turbat\">Turbat</ion-select-option>\r\n        <ion-select-option value=\"Umarao\">Umarao</ion-select-option>\r\n        <ion-select-option value=\"Umarkot\">Umarkot</ion-select-option>\r\n        <ion-select-option value=\"Upper Dir\">Upper Dir</ion-select-option>\r\n        <ion-select-option value=\"Uthal\">Uthal</ion-select-option>\r\n        <ion-select-option value=\"Vehari\">Vehari</ion-select-option>\r\n        <ion-select-option value=\"Veirwaro\">Veirwaro</ion-select-option>\r\n        <ion-select-option value=\"Vitakri\">Vitakri</ion-select-option>\r\n        <ion-select-option value=\"Wadh\">Wadh</ion-select-option>\r\n        <ion-select-option value=\"Wah Cantt\">Wah Cantt</ion-select-option>\r\n        <ion-select-option value=\"Warah\">Warah</ion-select-option>\r\n        <ion-select-option value=\"Washap\">Washap</ion-select-option>\r\n        <ion-select-option value=\"Wasjuk\">Wasjuk</ion-select-option>\r\n        <ion-select-option value=\"Wazirabad\">Wazirabad</ion-select-option>\r\n        <ion-select-option value=\"Yakmach\">Yakmach</ion-select-option>\r\n        <ion-select-option value=\"Zhob\">Zhob</ion-select-option>\r\n        <ion-select-option value=\"Other\">Other</ion-select-option>\r\n      </ion-select>\r\n    </ion-item>\r\n    <!-- child/patient name or father name searchbox -->\r\n    <ion-item>\r\n      <ion-label position=\"fixed\" color=\"primary\">Name</ion-label>\r\n      <ion-input type=\"text\" placeholder=\"Name or Father name\" formControlName=\"name\"></ion-input>\r\n    </ion-item>\r\n    <!-- search by date of birth -->\r\n    <ion-item>\r\n      <ion-label position=\"fixed\" color=\"primary\">DOB</ion-label>\r\n      <ion-datetime display-format=\"DD-MM-YYYY\" formControlName=\"dob\"></ion-datetime>\r\n    </ion-item>\r\n    <ion-item>\r\n        <ion-label position=\"fixed\" color=\"primary\">Gender</ion-label>\r\n        <ion-select formControlName=\"gender\" multiple=\"false\" placeholder=\"Select Gender\">\r\n            <ion-select-option value =''>Any</ion-select-option>\r\n          <ion-select-option value=\"Boy\">Male</ion-select-option>\r\n          <ion-select-option value=\"Girl\">Female</ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n    <ion-button block color=\"primary\" type=\"submit\" [disabled]=\"loginForm.invalid\">\r\n      Search\r\n    </ion-button>\r\n  </form>\r\n\r\n  <ion-card *ngIf=\"childs && childs.length == 0\">\r\n    <ion-card-header>\r\n      <ion-card-title>No patients found !</ion-card-title>\r\n    </ion-card-header>\r\n    <ion-card-content>\r\n      Server returned an empty response\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n  <ion-card *ngFor=\"let msg of childs\" class=\"boy\" [ngClass]=\"{'girl': msg.Gender=='Girl'}\">\r\n\r\n    <ion-item>\r\n      <ion-icon *ngIf=\"msg.Gender == 'Boy'\" name=\"man\" slot=\"start\" style=\"margin-right:16px\"></ion-icon>\r\n      <ion-icon *ngIf=\"msg.Gender == 'Girl'\" name=\"woman\" slot=\"start\" style=\"margin-right:16px\"></ion-icon>\r\n      <ion-label><b>{{msg.Name}}</b></ion-label>\r\n    </ion-item>\r\n\r\n    <ion-card-content>\r\n      <p>Father name: <b>{{msg.FatherName}}</b></p>\r\n      <p>DOB: <b>{{msg.DOB}}</b></p>\r\n      <p>Mobile number: <b>{{msg.MobileNumber}}</b></p>\r\n      <p>Gender: <b>{{msg.Gender}}</b></p>\r\n      <p>City: <b>{{msg.City}}</b></p>\r\n    </ion-card-content>\r\n  </ion-card>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/members/child/child.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/members/child/child.module.ts ***!
    \***********************************************/

  /*! exports provided: ChildPageModule */

  /***/
  function srcAppMembersChildChildModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChildPageModule", function () {
      return ChildPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _child_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./child.page */
    "./src/app/members/child/child.page.ts");

    var routes = [{
      path: '',
      component: _child_page__WEBPACK_IMPORTED_MODULE_6__["ChildPage"]
    }];

    var ChildPageModule = function ChildPageModule() {
      _classCallCheck(this, ChildPageModule);
    };

    ChildPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_child_page__WEBPACK_IMPORTED_MODULE_6__["ChildPage"]]
    })], ChildPageModule);
    /***/
  },

  /***/
  "./src/app/members/child/child.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/members/child/child.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppMembersChildChildPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".boy {\n  border: 1px solid blue;\n}\n\n.girl {\n  border: 1px solid pink;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVtYmVycy9jaGlsZC9FOlxcTmV3IGZvbGRlclxcVmFjQWRtaW4vc3JjXFxhcHBcXG1lbWJlcnNcXGNoaWxkXFxjaGlsZC5wYWdlLnNjc3MiLCJzcmMvYXBwL21lbWJlcnMvY2hpbGQvY2hpbGQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQUE7QUNDSjs7QURFQTtFQUNJLHNCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9tZW1iZXJzL2NoaWxkL2NoaWxkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib3kge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgYmx1ZVxyXG59XHJcblxyXG4uZ2lybCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCBwaW5rXHJcbn0iLCIuYm95IHtcbiAgYm9yZGVyOiAxcHggc29saWQgYmx1ZTtcbn1cblxuLmdpcmwge1xuICBib3JkZXI6IDFweCBzb2xpZCBwaW5rO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/members/child/child.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/members/child/child.page.ts ***!
    \*********************************************/

  /*! exports provided: ChildPage */

  /***/
  function srcAppMembersChildChildPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChildPage", function () {
      return ChildPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_child_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/child.service */
    "./src/app/services/child.service.ts");
    /* harmony import */


    var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/toast.service */
    "./src/app/shared/toast.service.ts");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);

    var ChildPage = /*#__PURE__*/function () {
      function ChildPage(formBuilder, loadingController, api, toastService) {
        _classCallCheck(this, ChildPage);

        this.formBuilder = formBuilder;
        this.loadingController = loadingController;
        this.api = api;
        this.toastService = toastService;
      }

      _createClass(ChildPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.loginForm = this.formBuilder.group({
            'city': [''],
            'name': [''],
            'dob': [''],
            'gender': ['']
          });
        }
      }, {
        key: "onSubmit",
        value: function onSubmit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    if (this.loginForm.controls['dob'].value !== '') {
                      this.loginForm.value.dob = moment__WEBPACK_IMPORTED_MODULE_6__(this.loginForm.value.dob, 'YYYY-MM-DD').format('YYYY-MM-DD');
                    }

                    _context.next = 8;
                    return this.api.searchChild(this.loginForm.controls['name'].value, this.loginForm.controls['city'].value, //this.loginForm.controls['dob'].value,
                    this.loginForm.value.dob, this.loginForm.controls['gender'].value).subscribe(function (res) {
                      if (res.IsSuccess) _this.childs = res.ResponseData;else _this.toastService.create(res.Message, 'danger');
                      loading.dismiss();
                    }, function (err) {
                      console.log(err);
                      loading.dismiss();
                    });

                  case 8:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return ChildPage;
    }();

    ChildPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: src_app_services_child_service__WEBPACK_IMPORTED_MODULE_4__["ChildService"]
      }, {
        type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"]
      }];
    };

    ChildPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-child',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./child.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/child/child.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./child.page.scss */
      "./src/app/members/child/child.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"], src_app_services_child_service__WEBPACK_IMPORTED_MODULE_4__["ChildService"], src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_5__["ToastService"]])], ChildPage);
    /***/
  },

  /***/
  "./src/app/services/child.service.ts":
  /*!*******************************************!*\
    !*** ./src/app/services/child.service.ts ***!
    \*******************************************/

  /*! exports provided: ChildService */

  /***/
  function srcAppServicesChildServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChildService", function () {
      return ChildService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _base_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./base.service */
    "./src/app/services/base.service.ts");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var ChildService = /*#__PURE__*/function (_base_service__WEBPAC) {
      _inherits(ChildService, _base_service__WEBPAC);

      var _super = _createSuper(ChildService);

      function ChildService(http) {
        var _this2;

        _classCallCheck(this, ChildService);

        _this2 = _super.call(this, http);
        _this2.http = http;
        _this2.API_CHILD = "".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].BASE_URL, "child");
        return _this2;
      }

      _createClass(ChildService, [{
        key: "searchChild",
        value: function searchChild(name, city, dob, gender) {
          var url = "".concat(this.API_CHILD, "/search?name=").concat(name, "&city=").concat(city, "&dob=").concat(dob, "&gender=").concat(gender);
          return this.http.get(url, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(this.extractData), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(this.handleError));
        }
      }]);

      return ChildService;
    }(_base_service__WEBPACK_IMPORTED_MODULE_2__["BaseService"]);

    ChildService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }];
    };

    ChildService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]])], ChildService);
    /***/
  }
}]);
//# sourceMappingURL=child-child-module-es5.js.map