function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-members-vaccine-dose-edit-edit-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/edit/edit.page.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/edit/edit.page.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMembersVaccineDoseEditEditPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Edit Dose</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n  <form [formGroup]=\"fg\">\r\n    <ion-item>\r\n      <ion-label color=\"primary\" floating>Name</ion-label>\r\n      <ion-input type=\"text\" formControlName=\"Name\" required></ion-input>\r\n\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label color=\"primary\" floating>Min Age</ion-label>\r\n      <ion-select formControlName=\"MinAge\" required>\r\n        <ion-select-option value=\"0\">At Birth</ion-select-option>\r\n        <ion-select-option value=\"7\">1 Week</ion-select-option>\r\n        <ion-select-option value=\"14\">2 Weeks</ion-select-option>\r\n        <ion-select-option value=\"21\">3 Weeks</ion-select-option>\r\n        <ion-select-option value=\"28\">4 Weeks</ion-select-option>\r\n        <ion-select-option value=\"35\">5 Weeks</ion-select-option>\r\n        <ion-select-option value=\"42\">6 Weeks</ion-select-option>\r\n        <ion-select-option value=\"49\">7 Weeks</ion-select-option>\r\n        <ion-select-option value=\"56\">8 Weeks</ion-select-option>\r\n        <ion-select-option value=\"63\">9 Weeks</ion-select-option>\r\n        <ion-select-option value=\"70\">10 Weeks</ion-select-option>\r\n        <ion-select-option value=\"77\">11 Weeks</ion-select-option>\r\n        <ion-select-option value=\"84\">3 Months</ion-select-option>\r\n        <ion-select-option value=\"91\">13 Weeks</ion-select-option>\r\n        <ion-select-option value=\"98\">14 Weeks</ion-select-option>\r\n        <ion-select-option value=\"105\">15 Weeks</ion-select-option>\r\n        <ion-select-option value=\"112\">16 Weeks</ion-select-option>\r\n        <ion-select-option value=\"119\">17 Weeks</ion-select-option>\r\n        <ion-select-option value=\"126\">18 Weeks</ion-select-option>\r\n        <ion-select-option value=\"133\">19 Weeks</ion-select-option>\r\n        <ion-select-option value=\"140\">20 Weeks</ion-select-option>\r\n        <ion-select-option value=\"147\">21 Weeks</ion-select-option>\r\n        <ion-select-option value=\"154\">22 Weeks</ion-select-option>\r\n        <ion-select-option value=\"161\">23 Weeks</ion-select-option>\r\n        <ion-select-option value=\"168\">6 Months</ion-select-option>\r\n        <ion-select-option value=\"212\">7 Months</ion-select-option>\r\n        <ion-select-option value=\"243\">8 Months</ion-select-option>\r\n        <ion-select-option value=\"274\">9 Months</ion-select-option>\r\n        <ion-select-option value=\"304\">10 Months</ion-select-option>\r\n        <ion-select-option value=\"334\">11 Months</ion-select-option>\r\n        <ion-select-option value=\"365\">1 Year</ion-select-option>\r\n        <ion-select-option value=\"395\">13 Months</ion-select-option>\r\n        <ion-select-option value=\"426\">14 Months</ion-select-option>\r\n        <ion-select-option value=\"456\">15 Months</ion-select-option>\r\n        <ion-select-option value=\"486\">16 Months</ion-select-option>\r\n        <ion-select-option value=\"517\">17 Months</ion-select-option>\r\n        <ion-select-option value=\"547\">18 Months</ion-select-option>\r\n        <ion-select-option value=\"578\">19 Months</ion-select-option>\r\n        <ion-select-option value=\"608\">20 Months</ion-select-option>\r\n        <ion-select-option value=\"639\">21 Months</ion-select-option>\r\n        <ion-select-option value=\"669\">22 Months</ion-select-option>\r\n        <ion-select-option value=\"699\">23 Months</ion-select-option>\r\n        <ion-select-option value=\"730\">2 Years</ion-select-option>\r\n        <ion-select-option value=\"760\">25 Months</ion-select-option>\r\n        <ion-select-option value=\"791\">26 Months</ion-select-option>\r\n        <ion-select-option value=\"821\">27 Months</ion-select-option>\r\n        <ion-select-option value=\"851\">28 Months</ion-select-option>\r\n        <ion-select-option value=\"882\">29 Months</ion-select-option>\r\n        <ion-select-option value=\"912\">30 Months</ion-select-option>\r\n        <ion-select-option value=\"943\">31 Months</ion-select-option>\r\n        <ion-select-option value=\"973\">32 Months</ion-select-option>\r\n        <ion-select-option value=\"1004\">33 Months</ion-select-option>\r\n        <ion-select-option value=\"1034\">34 Months</ion-select-option>\r\n        <ion-select-option value=\"1064\">35 Months</ion-select-option>\r\n        <ion-select-option value=\"1095\">3 Years</ion-select-option>\r\n        <ion-select-option value=\"1125\">37 Months</ion-select-option>\r\n        <ion-select-option value=\"1156\">38 Months</ion-select-option>\r\n        <ion-select-option value=\"1186\">39 Months</ion-select-option>\r\n        <ion-select-option value=\"1216\">40 Months</ion-select-option>\r\n        <ion-select-option value=\"1247\">41 Months</ion-select-option>\r\n        <ion-select-option value=\"1277\">42 Months</ion-select-option>\r\n        <ion-select-option value=\"1308\">43 Months</ion-select-option>\r\n        <ion-select-option value=\"1338\">44 Months</ion-select-option>\r\n        <ion-select-option value=\"1369\">45 Months</ion-select-option>\r\n        <ion-select-option value=\"1399\">46 Months</ion-select-option>\r\n        <ion-select-option value=\"1429\">47 Months</ion-select-option>\r\n        <ion-select-option value=\"1460\">4 Years</ion-select-option>\r\n        <ion-select-option value=\"1490\">49 Months</ion-select-option>\r\n        <ion-select-option value=\"1521\">50 Months</ion-select-option>\r\n        <ion-select-option value=\"1551\">51 Months</ion-select-option>\r\n        <ion-select-option value=\"1582\">52 Months</ion-select-option>\r\n        <ion-select-option value=\"1612\">53 Months</ion-select-option>\r\n        <ion-select-option value=\"1642\">54 Months</ion-select-option>\r\n        <ion-select-option value=\"1673\">55 Months</ion-select-option>\r\n        <ion-select-option value=\"1703\">56 Months</ion-select-option>\r\n        <ion-select-option value=\"1734\">57 Months</ion-select-option>\r\n        <ion-select-option value=\"1764\">58 Months</ion-select-option>\r\n        <ion-select-option value=\"1795\">59 Months</ion-select-option>\r\n        <ion-select-option value=\"1825\">5 Years</ion-select-option>\r\n        <ion-select-option value=\"2190\">6 Years</ion-select-option>\r\n        <ion-select-option value=\"2555\">7 Years</ion-select-option>\r\n        <ion-select-option value=\"2920\">8 Years</ion-select-option>\r\n        <ion-select-option value=\"3285\">9 Years</ion-select-option>\r\n        <ion-select-option value=\"3315\">9 Year 1 Month</ion-select-option>\r\n        <ion-select-option value=\"3650\">10 Years</ion-select-option>\r\n        <ion-select-option value=\"3833\">10 Year 6 Months</ion-select-option>\r\n        <ion-select-option value=\"4015\">11 Years</ion-select-option>\r\n        <ion-select-option value=\"4380\">12 Years</ion-select-option>\r\n        <ion-select-option value=\"4745\">13 Years</ion-select-option>\r\n        <ion-select-option value=\"5110\">14 Years</ion-select-option>\r\n        <ion-select-option value=\"5475\">15 Years</ion-select-option>\r\n      </ion-select>\r\n\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label color=\"primary\" floating>Max Age(optional)</ion-label>\r\n      <ion-select formControlName=\"MaxAge\">\r\n        <ion-select-option value=\"0\">At Birth</ion-select-option>\r\n        <ion-select-option value=\"42\">6 Weeks</ion-select-option>\r\n        <ion-select-option value=\"49\">7 Weeks</ion-select-option>\r\n        <ion-select-option value=\"56\">8 Weeks</ion-select-option>\r\n        <ion-select-option value=\"63\">9 Weeks</ion-select-option>\r\n        <ion-select-option value=\"70\">10 Weeks</ion-select-option>\r\n        <ion-select-option value=\"77\">11 Weeks</ion-select-option>\r\n        <ion-select-option value=\"84\">3 Months</ion-select-option>\r\n        <ion-select-option value=\"91\">13 Weeks</ion-select-option>\r\n        <ion-select-option value=\"98\">14 Weeks</ion-select-option>\r\n        <ion-select-option value=\"105\">15 Weeks</ion-select-option>\r\n        <ion-select-option value=\"112\">16 Weeks</ion-select-option>\r\n        <ion-select-option value=\"119\">17 Weeks</ion-select-option>\r\n        <ion-select-option value=\"126\">18 Weeks</ion-select-option>\r\n        <ion-select-option value=\"133\">19 Weeks</ion-select-option>\r\n        <ion-select-option value=\"140\">20 Weeks</ion-select-option>\r\n        <ion-select-option value=\"147\">21 Weeks</ion-select-option>\r\n        <ion-select-option value=\"154\">22 Weeks</ion-select-option>\r\n        <ion-select-option value=\"161\">23 Weeks</ion-select-option>\r\n        <ion-select-option value=\"168\">6 Months</ion-select-option>\r\n        <ion-select-option value=\"212\">7 Months</ion-select-option>\r\n        <ion-select-option value=\"243\">8 Months</ion-select-option>\r\n        <ion-select-option value=\"274\">9 Months</ion-select-option>\r\n        <ion-select-option value=\"304\">10 Months</ion-select-option>\r\n        <ion-select-option value=\"334\">11 Months</ion-select-option>\r\n        <ion-select-option value=\"365\">1 Year</ion-select-option>\r\n        <ion-select-option value=\"395\">13 Months</ion-select-option>\r\n        <ion-select-option value=\"426\">14 Months</ion-select-option>\r\n        <ion-select-option value=\"456\">15 Months</ion-select-option>\r\n        <ion-select-option value=\"486\">16 Months</ion-select-option>\r\n        <ion-select-option value=\"517\">17 Months</ion-select-option>\r\n        <ion-select-option value=\"547\">18 Months</ion-select-option>\r\n        <ion-select-option value=\"578\">19 Months</ion-select-option>\r\n        <ion-select-option value=\"608\">20 Months</ion-select-option>\r\n        <ion-select-option value=\"639\">21 Months</ion-select-option>\r\n        <ion-select-option value=\"669\">22 Months</ion-select-option>\r\n        <ion-select-option value=\"699\">23 Months</ion-select-option>\r\n        <ion-select-option value=\"730\">2 Years</ion-select-option>\r\n        <ion-select-option value=\"760\">25 Months</ion-select-option>\r\n        <ion-select-option value=\"791\">26 Months</ion-select-option>\r\n        <ion-select-option value=\"821\">27 Months</ion-select-option>\r\n        <ion-select-option value=\"851\">28 Months</ion-select-option>\r\n        <ion-select-option value=\"882\">29 Months</ion-select-option>\r\n        <ion-select-option value=\"912\">30 Months</ion-select-option>\r\n        <ion-select-option value=\"943\">31 Months</ion-select-option>\r\n        <ion-select-option value=\"973\">32 Months</ion-select-option>\r\n        <ion-select-option value=\"1004\">33 Months</ion-select-option>\r\n        <ion-select-option value=\"1034\">34 Months</ion-select-option>\r\n        <ion-select-option value=\"1064\">35 Months</ion-select-option>\r\n        <ion-select-option value=\"1095\">3 Years</ion-select-option>\r\n        <ion-select-option value=\"1125\">37 Months</ion-select-option>\r\n        <ion-select-option value=\"1156\">38 Months</ion-select-option>\r\n        <ion-select-option value=\"1186\">39 Months</ion-select-option>\r\n        <ion-select-option value=\"1216\">40 Months</ion-select-option>\r\n        <ion-select-option value=\"1247\">41 Months</ion-select-option>\r\n        <ion-select-option value=\"1277\">42 Months</ion-select-option>\r\n        <ion-select-option value=\"1308\">43 Months</ion-select-option>\r\n        <ion-select-option value=\"1338\">44 Months</ion-select-option>\r\n        <ion-select-option value=\"1369\">45 Months</ion-select-option>\r\n        <ion-select-option value=\"1399\">46 Months</ion-select-option>\r\n        <ion-select-option value=\"1429\">47 Months</ion-select-option>\r\n        <ion-select-option value=\"1460\">4 Years</ion-select-option>\r\n        <ion-select-option value=\"1490\">49 Months</ion-select-option>\r\n        <ion-select-option value=\"1521\">50 Months</ion-select-option>\r\n        <ion-select-option value=\"1551\">51 Months</ion-select-option>\r\n        <ion-select-option value=\"1582\">52 Months</ion-select-option>\r\n        <ion-select-option value=\"1612\">53 Months</ion-select-option>\r\n        <ion-select-option value=\"1642\">54 Months</ion-select-option>\r\n        <ion-select-option value=\"1673\">55 Months</ion-select-option>\r\n        <ion-select-option value=\"1703\">56 Months</ion-select-option>\r\n        <ion-select-option value=\"1734\">57 Months</ion-select-option>\r\n        <ion-select-option value=\"1764\">58 Months</ion-select-option>\r\n        <ion-select-option value=\"1795\">59 Months</ion-select-option>\r\n        <ion-select-option value=\"1825\">5 Years</ion-select-option>\r\n        <ion-select-option value=\"2190\">6 Years</ion-select-option>\r\n        <ion-select-option value=\"2555\">7 Years</ion-select-option>\r\n        <ion-select-option value=\"2920\">8 Years</ion-select-option>\r\n        <ion-select-option value=\"3285\">9 Years</ion-select-option>\r\n        <ion-select-option value=\"3315\">9 Year 1 Month</ion-select-option>\r\n        <ion-select-option value=\"3650\">10 Years</ion-select-option>\r\n        <ion-select-option value=\"3833\">10 Year 6 Months</ion-select-option>\r\n        <ion-select-option value=\"4015\">11 Years</ion-select-option>\r\n        <ion-select-option value=\"4380\">12 Years</ion-select-option>\r\n        <ion-select-option value=\"4745\">13 Years</ion-select-option>\r\n        <ion-select-option value=\"5110\">14 Years</ion-select-option>\r\n        <ion-select-option value=\"5475\">15 Years</ion-select-option>\r\n      </ion-select>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label color=\"primary\" floating>Min Gap from Prev Dose</ion-label>\r\n      <ion-select formControlName=\"MinGap\">\r\n        <ion-select-option value=\"0\">At Birth</ion-select-option>\r\n        <ion-select-option value=\"7\">1 Week</ion-select-option>\r\n        <ion-select-option value=\"14\">2 Weeks</ion-select-option>\r\n        <ion-select-option value=\"21\">3 Weeks</ion-select-option>\r\n        <ion-select-option value=\"28\">4 Weeks</ion-select-option>\r\n        <ion-select-option value=\"35\">5 Weeks</ion-select-option>\r\n        <ion-select-option value=\"42\">6 Weeks</ion-select-option>\r\n        <ion-select-option value=\"49\">7 Weeks</ion-select-option>\r\n        <ion-select-option value=\"56\">8 Weeks</ion-select-option>\r\n        <ion-select-option value=\"63\">9 Weeks</ion-select-option>\r\n        <ion-select-option value=\"70\">10 Weeks</ion-select-option>\r\n        <ion-select-option value=\"77\">11 Weeks</ion-select-option>\r\n        <ion-select-option value=\"84\">3 Months</ion-select-option>\r\n        <ion-select-option value=\"91\">13 Weeks</ion-select-option>\r\n        <ion-select-option value=\"98\">14 Weeks</ion-select-option>\r\n        <ion-select-option value=\"105\">15 Weeks</ion-select-option>\r\n        <ion-select-option value=\"112\">16 Weeks</ion-select-option>\r\n        <ion-select-option value=\"119\">17 Weeks</ion-select-option>\r\n        <ion-select-option value=\"126\">18 Weeks</ion-select-option>\r\n        <ion-select-option value=\"133\">19 Weeks</ion-select-option>\r\n        <ion-select-option value=\"140\">20 Weeks</ion-select-option>\r\n        <ion-select-option value=\"147\">21 Weeks</ion-select-option>\r\n        <ion-select-option value=\"154\">22 Weeks</ion-select-option>\r\n        <ion-select-option value=\"161\">23 Weeks</ion-select-option>\r\n        <ion-select-option value=\"168\">6 Months</ion-select-option>\r\n        <ion-select-option value=\"212\">7 Months</ion-select-option>\r\n        <ion-select-option value=\"243\">8 Months</ion-select-option>\r\n        <ion-select-option value=\"274\">9 Months</ion-select-option>\r\n        <ion-select-option value=\"304\">10 Months</ion-select-option>\r\n        <ion-select-option value=\"334\">11 Months</ion-select-option>\r\n        <ion-select-option value=\"365\">1 Year</ion-select-option>\r\n        <ion-select-option value=\"395\">13 Months</ion-select-option>\r\n        <ion-select-option value=\"426\">14 Months</ion-select-option>\r\n        <ion-select-option value=\"456\">15 Months</ion-select-option>\r\n        <ion-select-option value=\"486\">16 Months</ion-select-option>\r\n        <ion-select-option value=\"517\">17 Months</ion-select-option>\r\n        <ion-select-option value=\"547\">18 Months</ion-select-option>\r\n        <ion-select-option value=\"578\">19 Months</ion-select-option>\r\n        <ion-select-option value=\"608\">20 Months</ion-select-option>\r\n        <ion-select-option value=\"639\">21 Months</ion-select-option>\r\n        <ion-select-option value=\"669\">22 Months</ion-select-option>\r\n        <ion-select-option value=\"699\">23 Months</ion-select-option>\r\n        <ion-select-option value=\"730\">2 Years</ion-select-option>\r\n        <ion-select-option value=\"760\">25 Months</ion-select-option>\r\n        <ion-select-option value=\"791\">26 Months</ion-select-option>\r\n        <ion-select-option value=\"821\">27 Months</ion-select-option>\r\n        <ion-select-option value=\"851\">28 Months</ion-select-option>\r\n        <ion-select-option value=\"882\">29 Months</ion-select-option>\r\n        <ion-select-option value=\"912\">30 Months</ion-select-option>\r\n        <ion-select-option value=\"943\">31 Months</ion-select-option>\r\n        <ion-select-option value=\"973\">32 Months</ion-select-option>\r\n        <ion-select-option value=\"1004\">33 Months</ion-select-option>\r\n        <ion-select-option value=\"1034\">34 Months</ion-select-option>\r\n        <ion-select-option value=\"1064\">35 Months</ion-select-option>\r\n        <ion-select-option value=\"1095\">3 Years</ion-select-option>\r\n        <ion-select-option value=\"1125\">37 Months</ion-select-option>\r\n        <ion-select-option value=\"1156\">38 Months</ion-select-option>\r\n        <ion-select-option value=\"1186\">39 Months</ion-select-option>\r\n        <ion-select-option value=\"1216\">40 Months</ion-select-option>\r\n        <ion-select-option value=\"1247\">41 Months</ion-select-option>\r\n        <ion-select-option value=\"1277\">42 Months</ion-select-option>\r\n        <ion-select-option value=\"1308\">43 Months</ion-select-option>\r\n        <ion-select-option value=\"1338\">44 Months</ion-select-option>\r\n        <ion-select-option value=\"1369\">45 Months</ion-select-option>\r\n        <ion-select-option value=\"1399\">46 Months</ion-select-option>\r\n        <ion-select-option value=\"1429\">47 Months</ion-select-option>\r\n        <ion-select-option value=\"1460\">4 Years</ion-select-option>\r\n        <ion-select-option value=\"1490\">49 Months</ion-select-option>\r\n        <ion-select-option value=\"1521\">50 Months</ion-select-option>\r\n        <ion-select-option value=\"1551\">51 Months</ion-select-option>\r\n        <ion-select-option value=\"1582\">52 Months</ion-select-option>\r\n        <ion-select-option value=\"1612\">53 Months</ion-select-option>\r\n        <ion-select-option value=\"1642\">54 Months</ion-select-option>\r\n        <ion-select-option value=\"1673\">55 Months</ion-select-option>\r\n        <ion-select-option value=\"1703\">56 Months</ion-select-option>\r\n        <ion-select-option value=\"1734\">57 Months</ion-select-option>\r\n        <ion-select-option value=\"1764\">58 Months</ion-select-option>\r\n        <ion-select-option value=\"1795\">59 Months</ion-select-option>\r\n        <ion-select-option value=\"1825\">5 Years</ion-select-option>\r\n        <ion-select-option value=\"2190\">6 Years</ion-select-option>\r\n        <ion-select-option value=\"2555\">7 Years</ion-select-option>\r\n        <ion-select-option value=\"2920\">8 Years</ion-select-option>\r\n        <ion-select-option value=\"3285\">9 Years</ion-select-option>\r\n        <ion-select-option value=\"3315\">9 Year 1 Month</ion-select-option>\r\n        <ion-select-option value=\"3650\">10 Years</ion-select-option>\r\n        <ion-select-option value=\"3833\">10 Year 6 Months</ion-select-option>\r\n        <ion-select-option value=\"4015\">11 Years</ion-select-option>\r\n        <ion-select-option value=\"4380\">12 Years</ion-select-option>\r\n        <ion-select-option value=\"4745\">13 Years</ion-select-option>\r\n        <ion-select-option value=\"5110\">14 Years</ion-select-option>\r\n        <ion-select-option value=\"5475\">15 Years</ion-select-option>\r\n\r\n      </ion-select>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label color=\"primary\" floating>Dose Order</ion-label>\r\n      <ion-input type=\"text\" formControlName=\"DoseOrder\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label color=\"primary\" floating>Special</ion-label>\r\n      <ion-checkbox  formControlName=\"IsSpecial\"></ion-checkbox>\r\n    </ion-item>\r\n\r\n    <ion-button  [disabled]=\"!fg.valid\" (click)='editDose()'>Add</ion-button>\r\n  </form>\r\n  \r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/members/vaccine/dose/edit/edit.module.ts":
  /*!**********************************************************!*\
    !*** ./src/app/members/vaccine/dose/edit/edit.module.ts ***!
    \**********************************************************/

  /*! exports provided: EditPageModule */

  /***/
  function srcAppMembersVaccineDoseEditEditModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditPageModule", function () {
      return EditPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _edit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./edit.page */
    "./src/app/members/vaccine/dose/edit/edit.page.ts");

    var routes = [{
      path: '',
      component: _edit_page__WEBPACK_IMPORTED_MODULE_6__["EditPage"]
    }];

    var EditPageModule = function EditPageModule() {
      _classCallCheck(this, EditPageModule);
    };

    EditPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_edit_page__WEBPACK_IMPORTED_MODULE_6__["EditPage"]]
    })], EditPageModule);
    /***/
  },

  /***/
  "./src/app/members/vaccine/dose/edit/edit.page.scss":
  /*!**********************************************************!*\
    !*** ./src/app/members/vaccine/dose/edit/edit.page.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMembersVaccineDoseEditEditPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbWJlcnMvdmFjY2luZS9kb3NlL2VkaXQvZWRpdC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/members/vaccine/dose/edit/edit.page.ts":
  /*!********************************************************!*\
    !*** ./src/app/members/vaccine/dose/edit/edit.page.ts ***!
    \********************************************************/

  /*! exports provided: EditPage */

  /***/
  function srcAppMembersVaccineDoseEditEditPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditPage", function () {
      return EditPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/services/dose.service */
    "./src/app/services/dose.service.ts");
    /* harmony import */


    var src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/shared/toast.service */
    "./src/app/shared/toast.service.ts");

    var EditPage = /*#__PURE__*/function () {
      function EditPage(route, loadingController, doseService, router, formBuilder, toastService) {
        _classCallCheck(this, EditPage);

        this.route = route;
        this.loadingController = loadingController;
        this.doseService = doseService;
        this.router = router;
        this.formBuilder = formBuilder;
        this.toastService = toastService;
      }

      _createClass(EditPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.fg = this.formBuilder.group({
            'Name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            'MinAge': ['0', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            'MaxAge': [null],
            'MinGap': [null],
            'DoseOrder': [null],
            'VaccineId': [null],
            'IsSpecial': [false]
          });
          this.getDose();
        } // Get single Dose data by ID

      }, {
        key: "getDose",
        value: function getDose() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    _context.next = 7;
                    return this.doseService.getDoseById(this.route.snapshot.paramMap.get('id1')).subscribe(function (res) {
                      console.log(res);
                      _this.dose = res.ResponseData;
                      loading.dismiss();

                      _this.fg.controls['Name'].setValue(_this.dose.Name);

                      _this.fg.controls['MinAge'].setValue(_this.dose.MinAge + '');

                      if (_this.dose.MaxAge) _this.fg.controls['MaxAge'].setValue(_this.dose.MaxAge + '');
                      if (_this.dose.MinGap) _this.fg.controls['MinGap'].setValue(_this.dose.MinGap + '');

                      _this.fg.controls['DoseOrder'].setValue(_this.dose.DoseOrder);

                      _this.fg.controls['VaccineId'].setValue(_this.dose.VaccineId);

                      _this.fg.controls['IsSpecial'].setValue(_this.dose.IsSpecial);
                    }, function (err) {
                      console.log(err);
                      loading.dismiss();
                    });

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        } // Send the request server for Edit Dose

      }, {
        key: "editDose",
        value: function editDose() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this2 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.loadingController.create({
                      message: 'Loading'
                    });

                  case 2:
                    loading = _context2.sent;
                    _context2.next = 5;
                    return loading.present();

                  case 5:
                    _context2.next = 7;
                    return this.doseService.editDose(this.route.snapshot.paramMap.get('id1'), this.fg.value).subscribe(function (res) {
                      if (res.IsSuccess) {
                        loading.dismiss();

                        _this2.toastService.create('Dose updated successfully.');

                        _this2.router.navigateByUrl('/members/vaccine/' + _this2.route.snapshot.paramMap.get('id') + '/doses');
                      } else _this2.toastService.create(res.message, 'danger');
                    }, function (err) {
                      console.error(err);
                      _this2.toastService.create(err), 'danger';
                    });

                  case 7:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }]);

      return EditPage;
    }();

    EditPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_5__["DoseService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
      }, {
        type: src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"]
      }];
    };

    EditPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./edit.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/members/vaccine/dose/edit/edit.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./edit.page.scss */
      "./src/app/members/vaccine/dose/edit/edit.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"], src_app_services_dose_service__WEBPACK_IMPORTED_MODULE_5__["DoseService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], src_app_shared_toast_service__WEBPACK_IMPORTED_MODULE_6__["ToastService"]])], EditPage);
    /***/
  },

  /***/
  "./src/app/shared/toast.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/shared/toast.service.ts ***!
    \*****************************************/

  /*! exports provided: ToastService */

  /***/
  function srcAppSharedToastServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ToastService", function () {
      return ToastService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ToastService = /*#__PURE__*/function () {
      function ToastService(toastCtrl) {
        _classCallCheck(this, ToastService);

        this.toastCtrl = toastCtrl;
      }

      _createClass(ToastService, [{
        key: "create",
        value: function create(message) {
          var color = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "success";
          var ok = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
          var duration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 3000;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    if (this.toast) {
                      this.toast.dismiss();
                    }

                    _context3.next = 3;
                    return this.toastCtrl.create({
                      message: message,
                      color: color,
                      duration: ok ? null : duration,
                      position: 'bottom'
                    });

                  case 3:
                    this.toast = _context3.sent;
                    this.toast.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return ToastService;
    }();

    ToastService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])], ToastService);
    /***/
  }
}]);
//# sourceMappingURL=src-app-members-vaccine-dose-edit-edit-module-es5.js.map