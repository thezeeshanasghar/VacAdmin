export const environment = {
  production: true,

  // BASE_URL: "https://api.vaccs.io/api/"
  // BASE_URL: "http://vac-api.ehs.edu.pk/api/",
 // BASE_URL: "https://api.vaccs.io/api/",
 //  BASE_URL: "http://localhost:5000/api/",
 BASE_URL: "http://13.233.255.96:5002/api/",

 //  BASE_URL: "http://localhost:4309/api/",

  IS_LOGGED_IN: "IsLoggedIn"
};
